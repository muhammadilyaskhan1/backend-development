 
 <?php

 
  include('../admin_area/includes/connect.php');
  include('../admin_area/functions/common_functions.php');
 @session_start();
 

?>

 
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>

    /* Global Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f9fa; /* Set background color */
}

.container {
    padding-top: 50px; /* Add space from the top */
}

/* Form Styles */
.text-center {
    font-style: italic;
    font-size: 24px; /* Adjust font size */
    color: black;
    /* text-shadow: 1px 3px black; Add text shadow */
    font-weight: bold; /* Set font weight */
}

.login-form {
    max-width: 400px; /* Reduce max-width for better mobile responsiveness */
    margin: auto;
    padding: 20px;
    background-color: #fff; /* Change background color */
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Adjust box shadow */
}

.form-group {
    margin-bottom: 20px; /* Add margin bottom */
}

.form-control {
    border-radius: 5px; /* Adjust border radius */
}

.btn-primary {
    background-color: #007bff; /* Change button background color */
    border-color: #007bff; /* Change button border color */
}

.btn-primary:hover {
    background-color: #0056b3; /* Change button hover background color */
    border-color: #0056b3; /* Change button hover border color */
}

.Donothaveaccount {
    font-size: 18px; /* Adjust font size */
    padding-top: 10px; /* Add padding top */
    text-align: center;
}

.Donothaveaccount a {
    text-decoration: none;
    font-weight: bold;
    color: #007bff; /* Change link color */
}

.Donothaveaccount a:hover {
    text-decoration: underline; /* Add underline on hover */
    color: #0056b3; /* Change link hover color */
}

    </style>
    <head>
<body>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="text-center mb-4">User Login</h2>
      <form class="login-form" method="post" action="">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" name="user_email" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block" name="user_login">Login</button>
        <p class="Donothaveaccount">Don't have an account? <a href="users_registration.php">Register</a> </p>
      
      
      </form>


  
    </div>
  </div>
</div>

</body>
</html>

<?php
if(isset($_POST['user_login'])){
  $username=$_POST['username'];
  $user_email=$_POST['user_email'];

  //select the username and email from the user table check login 
  $sql_select=" SELECT * FROM user_table WHERE username='$username'AND user_email='$user_email'";
  $result=mysqli_query($conn,$sql_select);
  $row_count=mysqli_num_rows($result);
  $row_data=mysqli_fetch_assoc($result);
  $user_ip=getIPAddress();


  //cart item from the cards query
  $select_query_cart="SELECT * FROM `cart_details` WHERE ip_address='$user_ip'";
  $result_cart_item=mysqli_query($conn,  $select_query_cart);
  $result_card_row=mysqli_num_rows($result_cart_item);


  if($row_count>0){
   // echo"<script> alert('login succssfully')</script>";
    if($row_count==1 && $result_card_row==0){
      $_SESSION['username']=$username;
      echo"<script> alert('login succssfully')</script>";
      echo "<script>window.open('profile.php','_self')</script>";
    }
    else{
      $_SESSION['username']=$username;
      echo"<script> alert('login succssfully')</script>";
      echo "<script>window.open('profile.php','_self')</script>";
    }
  
  }
else{
  echo"<script> alert(' invalid Credentials')</script>";
}

}



?>



 