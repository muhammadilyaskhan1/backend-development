 
<?php
session_start();
include('../admin_area/includes/connect.php');

if (isset($_SESSION['admin_username'])) {
    $admin_username = $_SESSION['admin_username'];
    $admin_email = $_SESSION['admin_email'];

    // Delete the admin account from the database
    $sql_delete = "DELETE FROM `admin` WHERE admin_username='$admin_username' AND admin_email='$admin_email'";
    mysqli_query($conn, $sql_delete);
}

 
?>
