<style>
 


</style>
 <div class="footer">
 <p> All right reversed design by muhammad ilyas @2024</p>
</div>



