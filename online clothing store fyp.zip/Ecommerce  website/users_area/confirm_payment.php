<?php
include ('../admin_area/includes/connect.php');
session_start();
if (isset($_GET['order_id'])) {
  $order_id = $_GET['order_id'];
  $select_date = "SELECT * FROM `user_orders` WHERE order_id=$order_id";
  $result_query = mysqli_query($conn, $select_date);
  $row_order = mysqli_fetch_assoc($result_query);
  $invoice_number = $row_order['invoice_number'];
  $amount_due= $row_order['amount_due'];
}
$paymentModeError = "";

if (isset($_POST['confirm_payment'])) {
  $invoice_number = $_POST['invoice_number'];
  $amount = $_POST['amount'];
  $payment_mode = $_POST['payment_mode'];

  if(empty($payment_mode)) {
    $paymentModeError = "Please select a payment mode.";
  } else {
    // Assuming $conn is your database connection
    $insert_query = "INSERT INTO `user_payments`( `order_id`, `invoice_number`, `amount`, `payment_mode`) VALUES ('$order_id','$invoice_number','$amount ','$payment_mode')";
    // Execute the query
    $result = mysqli_query($conn, $insert_query);

    if ($result) {
      echo "<h3 class='text-center text-light'>Successfully completed the payment</h3>";
      echo "<script>window.open('profile.php?my_orders','_self')</script>";
    } else {
      echo "<h3 class='text-center text-light'>Failed to complete the payment</h3>";
    }
    $update_orders = "UPDATE `user_orders` SET order_status='complete' WHERE order_id=$order_id";
    $result_orders = mysqli_query($conn, $update_orders);
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS link -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <title>Payment Page</title>
</head>
<body class="bg-secondary">
  <div class="container my-5">
    <h1 class="text-center text-light">Confirm Payment</h1>
    <form action="" method="post">
      <div class="form-outline my-4 text-center w-50 m-auto">
        <input type="text" class="form-control w-50 m-auto" name="invoice_number" value="<?php echo $invoice_number ?> " readonly>
      </div>
      <div class="form-outline my-4 text-center w-50 m-auto">
        <label for="" class="text-light">Amount</label>
        <input type="text" class="form-control w-50 m-auto" name="amount" value="<?php echo $amount_due ?>" readonly>
        <!-- Add a message to inform the user -->
        <small class="text-muted">Note: Amount cannot be changed.</small>
      </div>
      <div class="form-outline my-4 text-center w-50 m-auto">
        <select name="payment_mode" class="form-select w-50 m-auto">
          <option value="">Select Payment Mode</option>
          <option value="Paypal">Paypal</option>
          <option value="jazzcash">jazzcash</option>
          <option value="Easypaisa">Easypaisa</option>
          <option value="Cash on Delivery">Cash on Delivery</option>
          <option value="pay offline">Pay Offline</option>
        </select>
        <!-- Display the validation error message -->
        <span class="cannotemptypaymentmode"><?php echo $paymentModeError; ?></span>
      </div>
      <div class="form-outline my-4 text-center w-50 m-auto">
        <input type="submit" class="bg-info py-2 px-3 border-0" name="confirm_payment" value="Confirm">
      </div>
    </form>
  </div>
  <style>
    .cannotemptypaymentmode{
      font-size: 24px;
      color: blue;
    }
  </style>
  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
