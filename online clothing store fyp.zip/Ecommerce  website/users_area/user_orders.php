    

<?php
include('../admin_area/includes/connect.php');
// session_start();
  // Make sure session_start() is called before accessing $_SESSION

 ?>
 
 




<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
      <!-- boostrap css link--->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 
    <title>Document</title>
</head>
<body>
    <?php
//  if(isset($_GET['my_orders'])){
 $username=$_SESSION['username']; 
   $sql_select="SELECT * FROM `user_table` WHERE username='$username'";
$result=mysqli_query($conn,$sql_select);
  $row_fetch=mysqli_fetch_assoc($result);
   $user_id=$row_fetch['user_id'];
 
 
 
 //}
?>

 
  
   <h3 class="text-success text-center">All my orders</h3>
   <table class="table table-borderd ">
    <thead class="bg-info">
<tr>
    <th>Sl no </th>
    <th>Amount due </th>
    <th>Total product</th>
    <th>Invoice number </th>
    <th>Date  </th>
    <th>Complete /incomplete </th>
    <th>status</th>
</tr>
 </thead>
 <tbody class="bg-secondary text-light">
  <?php
  
$get_order_details = "SELECT * FROM `user_orders` WHERE user_id=$user_id";
$result_query = mysqli_query($conn, $get_order_details);
$number = 1; // Initialize $number outside the loop

while ($row_order = mysqli_fetch_assoc($result_query)) {
    $order_id = $row_order['order_id'];
    $amount_due = $row_order['amount_due'];
    $total_products = $row_order['total_products'];
    $invoice_number = $row_order['invoice_number'];
    $order_date = $row_order['order_date'];
    $order_status = $row_order['order_status'];
    if($order_status=='pending'){
      $order_status='Incomplete';
    }else{
      $order_status='Complete';
    } 
    echo "
    <tr>
    <td>$number</td>
    <td>$amount_due</td>
    <td>$total_products</td>
    <td>$invoice_number</td>
    <td>$order_date</td>
    <td>$order_status</td>";
    ?>
    <?php
    if($order_status=='Complete'){
      echo"<td>Paid</td>";
    }
    else{

    echo"<td><a href='confirm_payment.php?order_id=$order_id' class='text-light'>confirm</a></td>
      </tr>";
    }
     
    
     
    $number++; // Increment $number
}
?>

 
 




   
       <!-- <tr>
         <td>1</td>
      <td>100</td>
      <td>3</td>
      <td>1243325</td>
      <td>124324</td>
      <td>Complete</td>
      <td>confirm</td>
     </tr> -->
 </tbody>
  

</table>
 


<style>

.table{
    width:70%;
    height: 500px;
    margin: auto;
 
}
</style>

 
</body>
</html>