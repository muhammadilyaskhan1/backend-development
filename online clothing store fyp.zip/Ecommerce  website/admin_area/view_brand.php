<?php
include('./includes/connect.php');

// Check if connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
  
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Custom CSS for table */
        .table-responsive {
            overflow-x: auto;
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 60%;
            margin: auto;
            height: 50%;

        }

        .table th,
        .table td {
            vertical-align: middle;
            text-align: center;
            font-size: 14px;
            border: 1px solid rgba(0, 0, 0, .1);
            padding: 10px;
        }

        .table th {
            background-color: #17a2b8;
            color: #fff;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, .05);
        }

        .table-bordered-mt-0 {
            margin-top: 10px;
        }

        .table th:last-child,
        .table td:last-child {
            white-space: nowrap;
        }

        .table th i,
        .table td i {
            margin-right: 2px;
        }

        .table th.actions,
        .table td.actions {
            width: 50px;
        }

        .table td {
            position: relative;
        }

        .table td span {
            display: none;
            position: absolute;
            top: 20%;
            left: 20%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            padding: 2px 5px;
            border-radius: 5px;
            z-index: 999;
        }

        .table td:hover span {
            display: block;
        }

        .productsviewimage {
            width: 200px;
            height: 300px;
            object-fit: cover;
        }

        #viewcate {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="text-center me-auto " id="viewcate">view brands</h1>
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-striped table-bordered-mt-0">
                <thead class="bg-info">
                    <tr>
                        <th>SLno</th>
                        <th>Brand Title</th>
                        <th class="actions">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $get_brands_query = "SELECT * FROM `brands`";
                    $get_brands_stmt = mysqli_prepare($conn, $get_brands_query);
                    mysqli_stmt_execute($get_brands_stmt);
                    $result = mysqli_stmt_get_result($get_brands_stmt);
                    $number = 0;
                    $brand_title = ""; // Initialize $brand_title here
                    while ($row = mysqli_fetch_assoc($result)) {
                        $brand_id = $row['brand_id'];
                        $brand_title = htmlspecialchars($row['brand_title']);
                        $number++;
                    ?>
                        <tr>
                            <td><?php echo $number ?></td>
                            <td><?php echo $brand_title ?></td>
                            <td class='actions'>
                                <a href='index.php?edit_brands=<?php echo $brand_id ?>' class='btn btn-primary btn-sm'><i class='fas fa-edit'></i> Edit</a>
                                <a href='index.php?delete_brands=<?php echo $brand_id ?> ' class='btn btn-danger btn-sm'><i class='fas fa-trash-alt'></i> Delete</a>
                            </td>
                        </tr>
                    <?php
                    }
                    mysqli_stmt_close($get_brands_stmt);
                    mysqli_close($conn);
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Bootstrap JS (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
