<?php
include('../admin_area/includes/connect.php');
  
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
 
if(isset($_GET['edit_products'])){
    $edit_id = $_GET['edit_products'];
    $get_data = "SELECT * FROM `products` WHERE product_id = $edit_id";
    $result = mysqli_query($conn, $get_data);
    $row_edit_product = mysqli_fetch_assoc($result);
    $product_title = $row_edit_product['product_title'];
    $product_description = $row_edit_product['product_description'];
    $product_keyword = $row_edit_product['product_keyword'];
    $category_id = $row_edit_product['category_id'];
    $brand_id = $row_edit_product['brand_id'];
    $product_status = 'true';

    // Fetching category
    $sql_category = "SELECT * FROM `category` WHERE category_id = $category_id";
    $result_category = mysqli_query($conn, $sql_category);
    $row_category = mysqli_fetch_assoc($result_category);
    $category_title = $row_category['category_title'];

    // Fetching brand
    $sql_brand = "SELECT * FROM `brands` WHERE brand_id = $brand_id";
    $result_brand = mysqli_query($conn, $sql_brand);
    $row_brand = mysqli_fetch_assoc($result_brand);
    $brand_title = $row_brand['brand_title'];
    
    //editing products
    if(isset($_POST['edit_product'])){
        $product_title = $_POST['product_title'];
        $product_description = $_POST['product_description'];
        $product_keyword = $_POST['product_keyword'];
        $product_category = $_POST['product_category'];
        $product_brands = $_POST['product_brands'];
        $product_price = $_POST['product_price'];
        $product_status = 'true';
        
        //for image name
        $product_image1 = $_FILES['product_image1']['name'];
        $product_image2 = $_FILES['product_image2']['name'];
        $product_image3 = $_FILES['product_image3']['name'];
        
        //for image temp name
        $temp_image1 = $_FILES['product_image1']['tmp_name'];
        $temp_image2 = $_FILES['product_image2']['tmp_name'];
        $temp_image3 = $_FILES['product_image3']['tmp_name'];
        if (
            $product_title == '' || $product_description == '' || $product_keyword == '' ||
            $product_category == '' || $product_brands == '' || $product_price == '' ||
            $product_image1 == '' || $product_image2 == '' || $product_image3 == ''
        ){
            echo "<script>alert('Please fill all the available fields and continue the process')</script>";
        }
        else {
            move_uploaded_file($temp_image1, "./product_images/$product_image1");
            move_uploaded_file($temp_image2, "./product_images/$product_image2");
            move_uploaded_file($temp_image3, "./product_images/$product_image3");

            $update_products = "UPDATE `products` SET 
                                product_title='$product_title', 
                                product_description='$product_description',
                                product_keyword='$product_keyword',
                                category_id='$product_category', 
                                brand_id='$product_brands',
                                product_price='$product_price',  
                                product_image1='$product_image1',  
                                product_image2='$product_image2',
                                product_image3='$product_image3' 
                                WHERE product_id=$edit_id";
            $result_update = mysqli_query($conn, $update_products);
            if($result_update){
                echo "<script> alert('Product updated successfully')</script>";
                echo "<script>window.open('./insert_product.php','_self')</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
</head>
<body>
    <div class="container">
        <h1 class="form-title">Edit Product</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <!-- product title -->
            <div class="mb-3">
                <label for="product_title" class="form-label">Product Title</label>
                <input type="text" name="product_title" id="product_title" class="form-control" placeholder="Enter product title" required="required" autocomplete="off" value="<?php echo $product_title ?>">
            </div>
            <!-- product description -->
            <div class="mb-3">
                <label for="product_description" class="form-label">Product Description</label>
                <input type="text" name="product_description" id="product_description" class="form-control" placeholder="Enter product description" required="required" autocomplete="off" value="<?php echo $product_description ?>">
            </div>
            <!-- product keyword -->
            <div class="mb-3">
                <label for="product_keyword" class="form-label">Product Keyword</label>
                <input type="text" name="product_keyword" id="product_keyword" class="form-control" placeholder="Enter product keyword" required="required" autocomplete="off" value="<?php echo $product_keyword ?>">
            </div>
            <!-- product category -->
            <div class="mb-3">
                <label for="product_category" class="form-label">Product Category</label>
                <select name="product_category" id="product_category" class="form-select">
                    <option value="<?php echo $category_id ?>"><?php echo $category_title ?></option>
                    <?php
                    $sql_select_query = "SELECT * FROM `category`";
                    $result = mysqli_query($conn, $sql_select_query);
                    while($row_category = mysqli_fetch_assoc($result)){
                        $category_id = $row_category['category_id'];
                        $category_title = $row_category['category_title'];
                        echo "<option value='$category_id'>$category_title</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- product brand -->
            <div class="mb-3">
                <label for="product_brands" class="form-label">Product Brand</label>
                <select name="product_brands" id="product_brands" class="form-select">
                    <option value="<?php echo $brand_id ?>"><?php echo $brand_title ?></option>
                    <?php
                    $sql_select_query = "SELECT * FROM `brands`";
                    $result = mysqli_query($conn, $sql_select_query);
                    while($row_brands = mysqli_fetch_assoc($result)){
                        $brand_id = $row_brands['brand_id'];
                        $brand_title = $row_brands['brand_title'];
                        echo "<option value='$brand_id'>$brand_title</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- product images -->
<div class="mb-3">
    <label for="product_image1" class="form-label">Product Image 1</label>
    <div class="image-container">
        <input type="file" name="product_image1" id="product_image1" class="form-control" required="required" autocomplete="off">
        <?php if(isset($row_edit_product['product_image1'])): ?>
            <img src="./product_images/<?php echo $row_edit_product['product_image1'] ?>" class="edit_image" alt="">
        <?php endif; ?>
    </div>
</div>
<!-- product image 2 -->
<div class="mb-3">
    <label for="product_image2" class="form-label">Product Image 2</label>
    <div class="image-container">
        <input type="file" name="product_image2" id="product_image2" class="form-control" autocomplete="off">
        <?php if(isset($row_edit_product['product_image2']) && !empty($row_edit_product['product_image2'])): ?>
            <img src="./product_images/<?php echo $row_edit_product['product_image2'] ?>" class="edit_image" alt="">
        <?php endif; ?>
    </div>
</div>
<!-- product image 3 -->
<div class="mb-3">
    <label for="product_image3" class="form-label">Product Image 3</label>
    <div class="image-container">
        <input type="file" name="product_image3" id="product_image3" class="form-control" autocomplete="off">
        <?php if(isset($row_edit_product['product_image3']) && !empty($row_edit_product['product_image3'])): ?>
            <img src="./product_images/<?php echo $row_edit_product['product_image3'] ?>" class="edit_image" alt="">
        <?php endif; ?>
    </div>
</div>

            <!-- product price -->
            <div class="mb-3">
                <label for="product_price" class="form-label">Product Price</label>
                <input type="text" name="product_price" id="product_price" class="form-control" placeholder="Enter product price" required="required" autocomplete="off" value="<?php echo $row_edit_product['product_price'] ?>">
            </div>
            <!-- submission button -->
            <div class="mb-3 text-center">
                <input type="submit" name="edit_product" id="edit_product" class="btn btn-info" value="Update Product">
            </div>
        </form>
    </div>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 700px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .form-title {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-radius: 5px;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .form-select {
            border-radius: 5px;
            height: 38px;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .form-select:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .btn {
            border-radius: 5px;
            width: 150px;
        }
        .edit_image{
            width: 100px; /* Adjust image size as needed */
            height: 100px; /* Adjust image size as needed */
            object-fit: cover;
            border-radius: 5px; /* Add border-radius for rounded corners */
            margin-left: 10px; /* Add spacing between image and input field */
        }
        .image-container {
            display: flex;
            align-items: center;
        }
    </style>


</body>
</html>
