<?php
  include('../admin_area/includes/connect.php');

 include('../admin_area/functions/common_functions.php');
 session_start();
 

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width= device-width, initial-scale=1.0">
  <title></title>
  <!-- boostrap css link--->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!---font awosome link---->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <!---stylecss--->
  <link rel="stylesheet" href="../clothingstore.css">
</head>

<body>
  <!---- navbar---->
  <nav class="navbar navbar-expand-lg navbar-light bg-info">
    <div class="container-fluid">
      <!-- <a class="navbar-brand" href="#">logo</a> -->
      <img src="../images/download.jpg" alt="" class="logo">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="../index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../display_all.php">products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="profile.php">My Account</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../cart.php"><i class="fa-solid fa-cart-plus"></i><sup>
           <?php
          cart_item();


           ?>
            </sup> </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"> Total price:<?php
            total_price_cart();
            
            ?>
            </a>
          </li>
          
        </ul>
        <form class="d-flex" action="../search_product.php" method="get">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"name="search_data">
       <!--  <button></button>--->
       <input type="submit" value="search" class="btn btn-outline-light" name="search_data_product">
        </form>

      </div>
    </div>
  </nav>
<!-- calling function in php-->
  <?php
cart();
  ?>




  <!-- second child -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
    <ul class="navbar-nav me-auto">

    
      <!-- <li class="nav-item">
        <a class="nav-link" href="#">welcome guest</a>
      </li> -->

      <?php
if(!isset($_SESSION['username'])){
  echo" <li class='nav-item'>
  <a class='nav-link' href='#'>welcome guest </a>
</li> 

  ";
 
}
else{
  echo"<li class='nav-item'>
        <a class='nav-link' href='#'>welcome ".$_SESSION['username']."</a></li>

  ";
}
 
if(!isset($_SESSION['username'])){
  echo"
  <li class='nav-item'>
        <a class='nav-link' href='./Users_area/user_login.php'>login</a></li>

  ";
 
}
else{
  echo"<li class='nav-item'>
        <a class='nav-link' href='./Users_area/logout.php'>logout</a></li>

  ";
}

?>
      <!-- <li class="nav-item">
        <a class="nav-link" href="Users_area/user_login.php">login</a>
      </li> -->

    </ul>
  </nav>
  <div class="hiddenstore"> 
   
  <h3 class=" text-center">ONLINE CLOTHING WEBSITE</h3>
  </div>

  <!-- products -->
  <div class="row">
    <div class="col-md-2 p-0">
        <ul class="navbar-nav bg-secondary text-center">
            <li class="nav-item ">
            <a class='nav-link text-light bg-info' href='#'>your profile</a></li>
            </li>
        

              <?php
 
// Check if the 'username' session variable is set
if(isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Establish your database connection ($conn should be defined before this)
    
    // Prepare and execute the query
    $user_image_query = "SELECT * FROM `user_table` WHERE username='$username'";
    $user_image_result = mysqli_query($conn, $user_image_query);

    // Check if the query was successful and if any rows were returned
    if($user_image_result && mysqli_num_rows($user_image_result) > 0) {
        // Fetch the row
        $row_image = mysqli_fetch_array($user_image_result);
        // Get the user image
        $user_image = $row_image['user_image'];

        // Output the image HTML
        echo "
        <li class='nav-item'>
            <img src='./user_image/$user_image' class='profile' alt=''>
        </li>";
    } else {
        // Handle the case where no rows were returned from the query
        echo "No user found with the username: $username";
    }

    // Free the result set
    mysqli_free_result($user_image_result);
} else {
    // Handle the case where the 'username' session variable is not set
    echo "Session variable 'username' is not set";
}












?>
            <!-- <li class="nav-item  ">
     <img src="../users_area/user_image/9a04bf3a446d0727620d87adf1974e1f_1694512897720_0.jpeg" class="profile" alt="">
            </li> -->


            <li class="nav-item ">
            <a class='nav-link text-light' href='profile.php'>pending order</a></li>
            </li>
            <li class="nav-item  ">
            <a class='nav-link text-light' href='profile.php?edit_account'>edit Account</a></li>
            </li>
            <li class="nav-item ">
            <a class='nav-link text-light' href='profile.php?my_orders'>my orders</a></li>
            </li> 
            <li class="nav-item ">
            <a class='nav-link text-light' href='profile.php?delete_account'>deleted account</a></li>
            </li>
            <li class="nav-item ">
            <a class='nav-link text-light' href='logout.php'>logout</a></li>
            </li>
    </ul>
 
    </div>
    <div class="col-md-10 text-center">
        <?php
get_user_order_details();
if(isset($_GET['my_orders'])){
 include('user_orders.php');
}
   
if(isset($_GET['edit_account'])){
  include('edit_account.php');
}
   
if(isset($_GET['delete_account'])){
  include('delete_account.php');
}
      ?>
        </div>
  </div>

 

<style>
 
 
.logo{
    width: 50px;
    height: 50px; 
}
.profile{
width: 80%;
height: 20%;
margin: auto;
display: block;
}
 /* Navbar Styles */
 .navbar{
  background-color: black /* Navbar background color */
}

.navbar-brand{
  padding: 0; /* Remove padding from the brand */
}

.navbar-brand img.logo{
  width: 50px; /* Adjust logo width */
  height: auto; /* Maintain aspect ratio */
}

.navbar-toggler{
  border: none; /* Remove default border */
}

.navbar-toggler-icon {
  background-color: #202020; /* Toggler icon color */
}

.navbar-nav .nav-link{
  color: #202020; /* Navbar link color */
}

.navbar-nav .nav-link.active{
  font-weight: bold; /* Style for active navbar link */
}

.navbar-nav .nav-link i{
  margin-right: 5px; /* Adjust margin between icon and text in navbar */
}

/* Responsive Navbar */
@media (max-width: 768px){
  .navbar-nav .nav-link{
    padding: 10px; /* Adjust link padding for smaller screens */
  }
}

/* Search Form Styles */
 /* Style for search form */
.d-flex {
  display: flex;
  align-items: center;
}

.form-control {
  border: 2px solid #ccc;
  border-radius: 5px;
  padding: 8px 12px;
  font-size: 16px;
  margin-right: 10px;
}

.btn {
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn:hover {
  background-color: #0056b3;
}

/* Responsive adjustments */
@media (max-width: 576px) {
  .form-control {
    width: 100%;
    margin-right: 0;''
  }
}

 
 
 

.navbar {
  background-color: black;
  padding: 10px;
  border-radius: 5px;
  
}

.navbar-nav {
  display: flex;
  justify-content: flex-end;
  margin: auto;
 
}

.nav-item {
  margin-left: 15px;
}

.nav-link {
  color: #fff;
  text-decoration: none;
 
}

.nav-link:hover {
  color: #3498db;
}



 
.hiddenstore{
  background-color: #CED2CC; /* Light background color */
  padding: 20px; /* Add some padding */
  margin-bottom: 10px;
  border-radius: 10px; /* Add rounded corners */
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Add a subtle shadow */
}

.text-center {
  text-align: center; /* Center align text */
  margin-bottom: 10px; /* Add some space below the text */
}

h3{
  color: #0091D5; /* Heading color */
  font-size: 24px; /* Heading font size */
  margin-top: 0; /* Remove top margin */
}

p{
  color: #0091D5; /* Paragraph text color */
  font-size: 18px; /* Paragraph font size */
  margin-bottom: 0; /* Remove bottom margin */
}







/*css code for category and brands section*/

/* Navbar Styles */
.col-md-2 {
  padding: 0; /* Remove default padding */
 padding-right: 10px;
}

.navbar-nav {
  padding: 0; /* Remove default padding */
 
}

.navbar-nav .nav-item {
  margin-bottom: 10px; /* Add margin between navbar items */
}

.navbar-nav .nav-item .nav-link {
  padding: 10px; /* Add padding to navbar links */
}

.navbar-nav .nav-item.bg-info {
  background-color: #17a2b8; /* Background color for navbar item */
}

.navbar-nav .nav-item .nav-link h4 {
  margin: 0px; /* Remove margin for h4 inside navbar link */
}

.navbar-nav .nav-item .nav-link {
  color: #fff; /* Text color for navbar links */
}

.navbar-nav .nav-item .nav-link:hover {
  background-color: #13545a; /* Background color on hover */
}

/* Optional: Add more styles as needed */


 
 

</style>

















  <!--boostrap js link---->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
</body>

</html>