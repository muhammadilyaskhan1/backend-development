 
<?php
if (!isset($_SESSION['admin_username'])) {
  echo "<script>alert('Please login first');</script>";
  header("Location: ../admin_area/adminlogin.php");
  exit();
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Advanced CSS Styling for Bootstrap Table</title>
   <!-- Bootstrap CSS -->
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
  <style>
    /* Custom CSS for table */
    .table-responsive {
      overflow-x: auto;
    }
    .table {
      border-collapse: separate;
      border-spacing: 0;
      width: 80%;
      margin: auto;
      height: 50%;
      
    }
    .table th, .table td {
      vertical-align: middle;
      text-align: center;
      font-size: 14px;
      border: 1px solid rgba(0,0,0,.1);
      padding: 10px;
    }
    .table th {
      background-color: #17a2b8;
      color: #fff;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: rgba(0,0,0,.05);
    }
    .table-bordered-mt-0 {
      margin-top: 10px;
    }
    .table th:last-child, .table td:last-child {
      white-space: nowrap;
    }
    .table th i, .table td i {
      margin-right: 2px;
    }
    .table th.actions, .table td.actions {
      width: 50px;
    }
    .table td {
      position: relative;
    }
    .table td span {
      display: none;
      position: absolute;
      top: 20%;
      left: 20%;
      transform: translate(-50%, -50%);
      background-color: rgba(0, 0, 0, 0.5);
      color: #fff;
      padding: 2px 5px;
      border-radius: 5px;
      z-index: 999;
    }
    .table td:hover span {
      display: block;
    }
    .productsviewimage{
      width: 200px;
      height: 300px;
      object-fit: cover;
    }
  </style>
</head>
<body>
  <div class="container">
    <h3 class="text-center text-success">All orders</h3>
    <div class="table-responsive">
      <table class="table table-bordered table-hover table-striped table-bordered-mt-0">
        <thead class="bg-info"> 
          <tr>
            <th>SLNO</th>
            <th>Amount due</th>
            <th>Invoice number</th>
            <th>Total products</th>
            <th>Order date</th>
            <th>Status</th>
            <th class='actions'>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php
          include('../admin_area/includes/connect.php');
          $get_orders = "SELECT * FROM `user_orders` ORDER BY `order_date` DESC";
          $result = mysqli_query($conn, $get_orders);
          $row_count = mysqli_num_rows($result);
             
          if ($row_count == 0) {
            echo "<tr><td colspan='7'><h2 class='bg-danger text-center mt-5'>No orders yet</h2></td></tr>";
          } else {
            $number = 0;
            while ($row_data = mysqli_fetch_assoc($result)) {
              $order_id = $row_data['order_id'];
              $user_id = $row_data['user_id'];
              $amount_due = $row_data['amount_due'];
              $invoice_number = $row_data['invoice_number'];
              $total_products = $row_data['total_products'];
              $order_date = $row_data['order_date'];
              $order_status = $row_data['order_status'];
              $number++;
              echo "
                <tr>
                  <td>$number</td>
                  <td>$amount_due</td>
                  <td>$invoice_number</td>
                  <td>$total_products</td>
                  <td>$order_date</td>
                  <td>$order_status</td>
                  <td class='actions'>
                    <a href='index.php?delete_list_orders=$order_id' class='btn btn-danger btn-sm'><i class='fas fa-trash-alt'></i> Delete</a>
                  </td>
                </tr>";
            }
          }
        ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bootstrap JS (optional) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
