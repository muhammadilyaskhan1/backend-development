<?php

//get product data from index page
function getproducts()
{
  global $conn;
  //condition to check isset or not
  if (!isset($_GET['category'])) {
    if (!isset($_GET['brand'])) {
      $sql = "SELECT * FROM `products` order by rand() LIMIT 0,6 ";
      $result = mysqli_query($conn, $sql);
      while ($row = mysqli_fetch_array($result)) {
        $product_id = $row['product_id'];
        $product_price = $row['product_price'];
        $product_title = $row['product_title'];
        $product_description = $row['product_description'];
        //$product_keyword = $row['product_keyword']; zarurat nahe hay date our status ke be zarurat nahe hay 
        $product_category = $row['category_id'];
        $product_brands = $row['brand_id'];
        $product_image1 = $row['product_image1'];
        //$product_status = 'true'; is ke zarurat nahe hay
        //echo $product_description;
        echo " 
      <div class='col-md-4 mb-4'>
      <div class='card custom-card'>
        <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Product Image'>
        <div class='card-body'>
          <h5 class='card-title'>$product_title</h5>
          <p class='card-text'>$product_description</p>
          <p class='card-price'>$product_price/:</p>
          <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
          <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
        </div>
      </div>
    </div>
      
      ";
      }
    }
  }
}


// geting unique category 
function get_unique_categories()
{
  global $conn;
  if (isset($_GET['category'])) {
    $category_id = $_GET['category'];
    //
    $sql = "SELECT * FROM `products` where category_id='$category_id'";
    $result = mysqli_query($conn, $sql);
    $num_of_rows = mysqli_num_rows($result);
    if ($num_of_rows == 0) {
      echo "<h2 class='text-center'> No stock for this category</h2>";
    }
    while ($row = mysqli_fetch_array($result)) {
      $product_id = $row['product_id'];
      $product_title = $row['product_title'];
      $product_description = $row['product_description'];
      //$product_keyword = $row['product_keyword']; zarurat nahe hay date our status ke be zarurat nahe hay 
      $product_category = $row['category_id'];
      $product_brands = $row['brand_id'];
      $product_image1 = $row['product_image1'];
      $product_price = $row['product_price'];
      //$product_status = 'true'; is ke zarurat nahe hay
      //echo $product_description;
      echo " 
    <div class='col-md-4 mb-4'>
    <div class='card custom-card'>
      <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Product Image'>
      <div class='card-body'>
        <h5 class='card-title'>$product_title</h5>
        <p class='card-text'>$product_description</p>
        <p class='card-price'>$product_price/:</p>
        <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
        <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
      </div>
    </div>
  </div>
  



    ";
    }


  }
}




// geting unique brands
function get_unique_brands()
{
  global $conn;
  if (isset($_GET['brand'])) {
    $brand_id = $_GET['brand'];
    //
    $sql = "SELECT * FROM `products` where brand_id='$brand_id'";
    $result = mysqli_query($conn, $sql);
    $num_of_rows = mysqli_num_rows($result);
    if ($num_of_rows == 0) {
      echo "<h2 class='text-center'>this  brand is not available for service</h2>";
    }
    while ($row = mysqli_fetch_array($result)) {
      $product_id = $row['product_id'];
      $product_title = $row['product_title'];
      $product_description = $row['product_description'];
      //$product_keyword = $row['product_keyword']; zarurat nahe hay date our status ke be zarurat nahe hay 
      $product_category = $row['category_id'];
      $product_brands = $row['brand_id'];
      $product_image1 = $row['product_image1'];
      $product_price = $row['product_price'];
      //$product_status = 'true'; is ke zarurat nahe hay
      //echo $product_description;
      echo " <div class='col-md-4 mb-4'>
      <div class='card custom-card'>
        <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Product Image'>
        <div class='card-body'>
          <h5 class='card-title'>$product_title</h5>
          <p class='card-text'>$product_description</p>
          <p class='card-price'>$product_price/:</p>
          <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
          <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
        </div>
      </div>
    </div>
      ";
    }


  }
}



// get brands dynamically 
function getbrands()
{
  global $conn;
  $sql = "SELECT * FROM `brands`";
  $select_brand = mysqli_query($conn, $sql);
  $row_brand = mysqli_num_rows($select_brand);
  //$data=mysqli_fetch_assoc($select_brand);
// echo $data['brand_title'];
  while ($data = mysqli_fetch_assoc($select_brand)) {
    $brand_title = $data['brand_title'];
    $brand_id = $data['brand_id'];
    //echo $brand_title,$brand_id;
    echo "<li class='nav-item '>
<a href='index.php?brand=$brand_id' class='nav-link text-light'>$brand_title  </a>
</li>";
  }


}
// display categories is data ko hom na index.php may lekay ta leken hom is ko function kay zareya asan karsaktay hay
function getcategories()
{
  global $conn;
  $sql = "SELECT * FROM `category`";
  $select_category = mysqli_query($conn, $sql);
  $row_category = mysqli_num_rows($select_category);
  //$data=mysqli_fetch_assoc($select_brand);
// echo $data['category_title'];
  while ($data = mysqli_fetch_assoc($select_category)) {
    $category_id = $data['category_id'];
    $category_title = $data['category_title'];

    //echo $category_title,$category_id;
    echo "<li class='nav-item '>
<a href='index.php?category=$category_id' class='nav-link text-light'>$category_title  </a>
</li>";
  }




}


// searching products functions

function search_product()
{
  global $conn;
  if (isset($_GET['search_data_product'])) {
    $serarch_data_value = $_GET['search_data'];
    $search_query = "SELECT * FROM `products` WHERE product_keyword like '%$serarch_data_value%' ";
    $result = mysqli_query($conn, $search_query);
    $num_of_rows = mysqli_num_rows($result);
    if ($num_of_rows == 0) {
      echo "<h2 class='text-center'> No result match. No products found on this category!</h2>";
    }
    while ($row = mysqli_fetch_array($result)) {
      $product_id = $row['product_id'];
      $product_title = $row['product_title'];
      $product_description = $row['product_description'];
      //$product_keyword = $row['product_keyword']; zarurat nahe hay date our status ke be zarurat nahe hay 
      $product_category = $row['category_id'];
      $product_brands = $row['brand_id'];
      $product_image1 = $row['product_image1'];
      $product_price = $row['product_price'];
      //$product_status = 'true'; is ke zarurat nahe hay
      //echo $product_description;
      echo " <div class='col-md-4 mb-4'>
    <div class='card custom-card'>
      <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Product Image'>
      <div class='card-body'>
        <h5 class='card-title'>$product_title</h5>
        <p class='card-text'>$product_description</p>
        <p class='card-price'>$product_price/:</p>
        <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
        <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
      </div>
    </div>
  </div>
    ";
    }

  }
}
// display all product(in navbar ) function 
function display_allproduct()
{
  global $conn;
  if (!isset($_GET['category'])) {
    if (!isset($_GET['brand'])) {
      $sql = "SELECT * FROM `products` order by rand() ";
      $result = mysqli_query($conn, $sql);
      while ($row = mysqli_fetch_array($result)) {
        $product_id = $row['product_id'];
        $product_title = $row['product_title'];
        $product_description = $row['product_description'];
        //$product_keyword = $row['product_keyword']; zarurat nahe hay date our status ke be zarurat nahe hay 
        $product_category = $row['category_id'];
        $product_brands = $row['brand_id'];
        $product_image1 = $row['product_image1'];
        $product_price = $row['product_price'];
        //$product_status = 'true'; is ke zarurat nahe hay
        //echo $product_description;
        echo " <div class='col-md-4 mb-4'>
    <div class='card custom-card'>
      <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Product Image'>
      <div class='card-body'>
        <h5 class='card-title'>$product_title</h5>
        <p class='card-text'>$product_description</p>
        <p class='card-price'>$product_price/:</p>
        <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
        <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
      </div>
    </div>
  </div>
    ";
      }
    }

  }

}
//get view data

function getmoredetail()
{
  global $conn;
  if (isset($_GET['product_id'])) {
    if (!isset($_GET['category'])) {
      if (!isset($_GET['brand'])) {
        $product_id = $_GET['product_id'];
        $sql = "SELECT * FROM `products` where product_id='$product_id'";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_array($result)) {
          $product_id = $row['product_id'];
          $product_title = $row['product_title'];
          $product_description = $row['product_description'];
          $product_price = $row['product_price'];
          $product_category = $row['category_id'];
          $product_brands = $row['brand_id'];
          $product_image1 = $row['product_image1'];
          $product_image2 = $row['product_image2'];
          $product_image3 = $row['product_image3'];
          echo "  <div class='col-md-4 mb-4'>
          <div class='card custom-card'>
            <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Product Image'>
            <div class='card-body'>
              <h5 class='card-title'>$product_title</h5>
              <p class='card-text'>$product_description</p>
              <p class='card-price'>$product_price/:</p>
              <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
              <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
            </div>
          </div>
        </div>

        <div class='col-md-4 mb-4'>
        <div class='card custom-card'>
          <img class='card-img-top' src='.\admin_area\product_images/$product_image2' alt='Product Image'>
          <div class='card-body'>
       
            <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
            <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
          </div>
        </div>
      </div>

 
   
      <div class='col-md-4 mb-4'>
      <div class='card custom-card'>
        <img class='card-img-top' src='.\admin_area\product_images/$product_image3' alt='Product Image'>
        <div class='card-body'>
   
          <a href='index.php?add_to_cart=$product_id' class='btn btn-info'>Add to Cart</a>
          <a href='product_details.php?product_id=$product_id' class='btn btn-secondary'>View More</a>
        </div>
      </div>
    </div>
 



 
    ";
          
        }
      }
    }
  }


}
// get ip function
function getIPAddress()
{
  // Check if the IP is from a shared internet connection
  if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
  }
  // Check if the IP is from a proxy
  elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  }
  // Otherwise, assume the IP is from the remote address
  else {
    $ip = $_SERVER['REMOTE_ADDR'];
  }
  return $ip;
}

// $ip = getIPAddress();  
// echo 'User Real IP Address - '.$ip;  

// function cart()
// {
//   if (isset($_GET['add_to_cart'])) {
//     global $conn;
//     $get_product_id = $_GET['add_to_cart'];
//     $get_ip_add = getIPAddress(); 
      
//     $sql = "SELECT * FROM `cart_details` WHERE product_id='$get_product_id'  AND ip_address='$get_ip_add' ";
//     $result = mysqli_query($conn, $sql);
//     $num_of_rows = mysqli_num_rows($result);
//     if ($num_of_rows > 0) {
//       echo "<script>alert('this item is already present inside cart') ";
//       echo "<script>window.open('index.php','_self')</script>";
//     } else {

//       $sql = "INSERT INTO`cart_details`(product_id,ip_address,quantity) VALUES ('$get_product_id','$get_ip_add','1')";
//       $result = mysqli_query($conn, $sql);
//       echo "<script>alert(' item added to cart') ";
//       echo "<script>window.open('index.php','_self')</script>";
//     }
//   }
// }
 
function cart()
{
    if (isset($_GET['add_to_cart'])) {
        global $conn;
        $get_product_id = $_GET['add_to_cart'];
        $get_ip_add = getIPAddress();

        // Check if the product is already in the cart
        $sql = "SELECT * FROM `cart_details` WHERE product_id='$get_product_id' AND ip_address='$get_ip_add'";
        $result = mysqli_query($conn, $sql);
        $num_of_rows = mysqli_num_rows($result);

        if ($num_of_rows > 0) {
            // Product is already in the cart, update the quantity
            $row = mysqli_fetch_assoc($result);
            $current_quantity = $row['quantity'];
            $new_quantity = $current_quantity + 1;

            $update_sql = "UPDATE `cart_details` SET quantity='$new_quantity' WHERE product_id='$get_product_id' AND ip_address='$get_ip_add'";
            $update_result = mysqli_query($conn, $update_sql);
           
            if ($update_result) {
                echo "<script>alert('Item quantity updated in cart')</script>";
            } else {
                echo "<script>alert('Failed to update item quantity')</script>";
            }
        } else {
            // Product is not in the cart, insert it
            $insert_sql = "INSERT INTO `cart_details` (product_id, ip_address, quantity) VALUES ('$get_product_id', '$get_ip_add', '1')";
            $insert_result = mysqli_query($conn, $insert_sql);

            if ($insert_result) {
                echo "<script>alert('Item added to cart')</script>";
            } else {
                echo "<script>alert('Failed to add item to cart')</script>";
            }
        }

        echo "<script>window.open('index.php', '_self')</script>";
    }
}








// function to get cart item number 
// copy code from cart funtion and changes

function cart_item()
{

  if (isset($_GET['add_to_cart'])) {
    global $conn;
   $get_ip_add = getIPAddress();   
    $get_product_id = $_GET['add_to_cart'];   
    $sql = "SELECT * FROM `cart_details`WHERE ip_address='$get_ip_add'";
    $result = mysqli_query($conn, $sql);
    $num_of_rows = mysqli_num_rows($result);
  } else {
    global $conn;
   $get_ip_add = getIPAddress();
   
    $sql = "SELECT * FROM `cart_details`WHERE ip_address='$get_ip_add'  ";
    $result = mysqli_query($conn, $sql);
    $num_of_rows = mysqli_num_rows($result);
  }
  echo $num_of_rows;


}

// cart total
 

function total_price_cart()
{
  global $conn; // Assuming $conn is your database connection obje
  // Function to get user's IP addres
  $get_ip_add = getIPAddress();
  $total_price = 0;
  // SQL query to select items in the cart based on user's IP address
  $sql = "SELECT * FROM `cart_details` WHERE ip_address='$get_ip_add'";
  $result_cards = mysqli_query($conn, $sql);

  // Iterate over cart items
  while ($row = mysqli_fetch_array($result_cards)) {
    $product_id = $row['product_id'];

    // Fetch product details from products table
    $select_query = "SELECT * FROM `products` WHERE product_id='$product_id'";
    $result_query = mysqli_query($conn, $select_query);
    // Iterate over product details
    while ($row_product_price = mysqli_fetch_array($result_query)) {
      // Extract product price and add it to total price
      $product_price = array($row_product_price['product_price']);
      $product_value = array_sum($product_price);
      $total_price += $product_value;
      //Output the total price

    }

  }
  echo $total_price;
}

function get_user_order_details()
{
  global $conn;
  $username = $_SESSION['username'];
  // Get user details
  $get_user_details ="SELECT * FROM `user_table` WHERE username='$username'";
  $result_user_detail= mysqli_query($conn, $get_user_details);
  while ($user_row = mysqli_fetch_array($result_user_detail)){
    $user_id = $user_row['user_id'];
    if (!isset($_GET['edit_accout'])) {
      if (!isset($_GET['my_orders'])) {
        $get_order = "SELECT * FROM `user_orders` WHERE user_id='$user_id' AND order_status='pending'";
        $result_orders = mysqli_query($conn, $get_order);
        $row_count = mysqli_num_rows($result_orders);
        if ($row_count>0) {
          echo "<h3 class='text-center text-success mt-5 mb-2'> You have <span class='text-danger'>$row_count</span> pending orders</h3>
        <p class='text-center'><a href='profile.php?my_orders' class='text-dark'>Order details</a></p>";
        } 
        else {
          echo "<h3 class='text-center text-success mt-5 mb-2'> You have <span class='text-danger'>$row_count</span> zero pending orders</h3>
          <p class='text-center'><a href='../index.php' class='text-dark'>Explore products</a></p>";
        }

      }
    }

  }

}
 
  
 