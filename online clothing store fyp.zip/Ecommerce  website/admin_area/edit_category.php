<?php
include('../admin_area/includes/connect.php');
 
  
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
if(isset($_GET['edit_category'])){
    $edit_category = $_GET['edit_category'];
    $get_category_query = "SELECT * FROM `category` WHERE category_id=?";
    $stmt = mysqli_prepare($conn, $get_category_query);
    mysqli_stmt_bind_param($stmt, "i", $edit_category);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if(mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $category_title = $row['category_title'];
        
        if(isset($_POST['Edit_category'])) {
            $category_title = $_POST['category_title'];
            $update_category_query = "UPDATE `category` SET category_title=? WHERE category_id=?";
            $stmt = mysqli_prepare($conn, $update_category_query);
            mysqli_stmt_bind_param($stmt, "si", $category_title, $edit_category);
            $result = mysqli_stmt_execute($stmt);
            
            if($result) {
                echo "<script>alert('Category has been updated successfully');</script>";
                echo "<script>window.open('./view_category.php','_self');</script>";
            } else {
                echo "<script>alert('Failed to update category');</script>";
            }
        }
    } else {
        echo "<script>alert('Category not found');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category</title>
</head>
<body>
    <h3 class="text-center text-success" id="viewcate">Edit Category</h3>
    <form action="" method="post" class="mb-2">
        <div class="input-group mb-3 w*90" >
            <span class="input-group-text" id="basic-addon1 bg-info" ><i class="fa-solid fa-receipt"></i></span>
            <input type="text" class="form-control" name="category_title" placeholder="Update Category" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo isset($category_title) ? $category_title : ''; ?>">
        </div>
        <div class="input-group mb-0 w*10">
            <input type="submit" name="Edit_category" class="bg-info p-4 border-0 my-3" > 
        </div>
    </form>
    <style>
        /* Form Styles */
        form {
            max-width: 400px; /* Adjust form width */
            margin: 0 auto;
        }

        .input-group {
            margin-bottom: 15px; /* Adjust spacing between input groups */
        }

        .input-group-text {
            background-color: #17a2b8; /* Input group text background color */
            color: #fff; /* Input group text color */
        }

        .input-group input {
            border-radius: 0; /* Remove border-radius for input */
        }

        .input-group button {
            border-radius: 0; /* Remove border-radius for button */
            cursor: pointer;
        }

        /* Button Styles */
        input[type="submit"],
        button {
            background-color: #17a2b8; /* Button background color */
            color: #fff; /* Button text color */
            border: none;
            padding: 10px 20px; /* Adjust button padding */
        }

        input[type="submit"]:hover,
        button:hover {
            background-color: #117a8b; /* Button background color on hover */
        }

        /* Responsive Styles */
        @media (max-width: 576px) {
            form {
                max-width: 90%; /* Adjust form width for smaller screens */
            }
        }
        #viewcate {
            text-align: center;
        }
    </style>
</body>
</html>
