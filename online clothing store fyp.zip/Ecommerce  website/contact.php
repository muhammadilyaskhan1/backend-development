<?php

// Set SMTP server configuration
ini_set('SMTP', 'smtp.example.com');
ini_set('smtp_port', 587);

include ('./admin_area/includes/connect.php');

// Output messages
$responses = [];

// Check if the form was submitted
if (isset($_POST['email'], $_POST['subject'], $_POST['name'], $_POST['msg'])) {
	// Validate email address
	if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
		$responses[] = 'Email is not valid!';
	}
	// Make sure the form fields are not empty
	if (empty($_POST['email']) || empty($_POST['subject']) || empty($_POST['name']) || empty($_POST['msg'])) {
		$responses[] = 'Please complete all fields!';
	} 
	// If there are no errors
	if (!$responses) {
		// Where to send the mail? It should be your email address
		$to      = 'ik248457@gmail.com';
		// Send mail from which email address?
		$from = 'senderemail@gmail.com';
		// Mail subject
		$subject = $_POST['subject'];
		// Mail message
		$message = $_POST['msg'];
		// Mail headers
		$headers = 'From: ' . $from . "\r\n" . 'Reply-To: ' . $_POST['email'] . "\r\n" . 'X-Mailer: PHP/' . phpversion();
		// Try to send the mail
		if (mail($to, $subject, $message, $headers)) {
			// Success
			$responses[] = 'Email sent successfully!';
			
			// Insert data into the database
			$email = $_POST['email'];
			$name = $_POST['name'];
			$subject = $_POST['subject'];
			$msg = $_POST['msg'];
			
			$insert_query = "INSERT INTO contact_messages (email, name, subject, message) VALUES ('$email', '$name', '$subject', '$msg')";
			if (mysqli_query($conn, $insert_query)) {
				$responses[] = 'Data inserted into the database!';
			} else {
				$responses[] = 'Error inserting data into the database: ' . mysqli_error($conn);
			}
		} else {
			// Fail
			$responses[] = 'Failed to send email! Please check your mail server settings!';
		}
	}
}

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,minimum-scale=1">
		<title>Contact Form</title>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<div class="container">
			<form class="contact" method="post" action="">
				<h1>Contact Form</h1>
				<div class="fields">
					<label for="email">
						<i class="fas fa-envelope"></i>
						<input id="email" type="email" name="email" placeholder="Your Email" required>
					</label>
					<label for="name">
						<i class="fas fa-user"></i>
						<input type="text" name="name" placeholder="Your Name" required>
					<label>
					<input type="text" name="subject" placeholder="Subject" required>
					<textarea name="msg" placeholder="Message" required></textarea>
				</div>
				<input type="submit">
			</form>

			<div class="response">
				<?php foreach ($responses as $response): ?>
					<p><?php echo $response; ?></p>
				<?php endforeach; ?>
			</div>
		</div>
	</body>

    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
}

.container {
    max-width: 600px;
  margin: auto;
}

.contact {
 
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.contact h1 {
    font-size: 24px;
    text-align: center;
    margin-bottom: 20px;
}

.fields {
    margin-bottom: 20px;
}

.fields label {
    display: block;
    margin-bottom: 10px;
}

.fields input[type="email"],
.fields input[type="text"],
.fields textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

.fields textarea {
    height: 100px;
}

input[type="submit"] {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    border: none;
    border-radius: 5px;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

.response p {
    padding: 10px;
    margin-top: 10px;
    border-radius: 5px;
}

.response p.success {
    background-color: #dff0d8;
    color: #3c763d;
}

.response p.error {
    background-color: #f2dede;
    color: #a94442;
}

i {
    margin-right: 10px;
}

    </style>
</html>
