<?php



include('./includes/connect.php');

 
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 


if(isset($_POST['insert_product'])){
    $product_title = $_POST['product_title'];
    $product_description = $_POST['product_description'];
    $product_keyword = $_POST['product_keyword'];
    $product_category = $_POST['product_category'];
    $product_brands = $_POST['product_brands'];
    $product_price = $_POST['product_price'];
    $product_status = 'true';
    
    //for image name
    $product_image1 = $_FILES['product_image1']['name'];
    $product_image2 = $_FILES['product_image2']['name'];
    $product_image3 = $_FILES['product_image3']['name'];
    
    //for image temp name
    $temp_image1 = $_FILES['product_image1']['tmp_name'];
    $temp_image2 = $_FILES['product_image2']['tmp_name'];
    $temp_image3 = $_FILES['product_image3']['tmp_name'];

    // Validation for product title - no numbers
    if (preg_match('/[0-9]/', $product_title)) {
        echo "<script>alert('Product title cannot contain numbers');</script>";
    }
    // Validation for product description - maximum 200 words
    elseif (str_word_count($product_description) > 200) {
        echo "<script>alert('Product description cannot exceed 200 words');</script>";
    }
    // Validation for product price - only numbers allowed
    elseif (!is_numeric($product_price)) {
        echo "<script>alert('Product price should contain only numbers');</script>";
    }
    // Check if any required field is empty
    elseif (
        $product_title == '' || $product_description == '' || $product_keyword == '' ||
        $product_category == '' || $product_brands == '' || $product_price == '' ||
        $product_image1 == '' || $product_image2 == '' || $product_image3 == ''
    ){
        echo "<script>alert('Please fill all the available fields')</script>";
    } else {
        move_uploaded_file($temp_image1, "./product_images/$product_image1");
        move_uploaded_file($temp_image2, "./product_images/$product_image2");
        move_uploaded_file($temp_image3, "./product_images/$product_image3");

        $sql = "INSERT INTO `products` 
                (`product_title`, `product_description`, `product_keyword`, `category_id`, `brand_id`, 
                `product_image1`, `product_image2`, `product_image3`, `product_price`, `date`, `status`) 
                VALUES ('$product_title','$product_description','$product_keyword','$product_category',
                '$product_brands','$product_image1','$product_image2','$product_image3','$product_price',NOW(),'$product_status')";

        $product_query = mysqli_query($conn, $sql);

        if($product_query){
            echo "<script>alert('Successfully inserted the product')</script> ";
        } else {
            echo('Could not insert product into the database: ' . mysqli_error($conn));
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 700px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .form-title {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border-radius: 5px;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .form-control:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .form-select {
            border-radius: 5px;
            height: 38px;
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .form-select:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .btn {
            border-radius: 5px;
            width: 150px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="form-title">Insert Product</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <!-- product title -->
            <div class="mb-3">
                <label for="product_title" class="form-label">Product Title</label>
                <input type="text" name="product_title" id="product_title" class="form-control" placeholder="Enter product title" required="required" autocomplete="off">
            </div>
            <!-- product description -->
            <div class="mb-3">
                <label for="product_description" class="form-label">Product Description</label>
                <input type="text" name="product_description" id="product_description" class="form-control" placeholder="Enter product description" required="required" autocomplete="off">
            </div>
            <!-- product keyword -->
            <div class="mb-3">
                <label for="product_keyword" class="form-label">Product Keyword</label>
                <input type="text" name="product_keyword" id="product_keyword" class="form-control" placeholder="Enter product keyword" required="required" autocomplete="off">
            </div>
            <!-- product category -->
            <div class="mb-3">
                <label for="product_category" class="form-label">Product Category</label>
                <select name="product_category" id="product_category" class="form-select">
                    <option value="">Select a category</option>
                    <?php 
                    $select_query="Select * from `category`";
                    $result_select=mysqli_query($conn,$select_query);
                    while($data=mysqli_fetch_assoc($result_select)){
                        $category_id=$data['category_id'];
                        $category_title=$data['category_title'];
                        echo"<option value='$category_id'>   $category_title  </option>";
                    }
                    ?>
                </select>
            </div>
            <!-- product brand -->
            <div class="mb-3">
                <label for="product_brands" class="form-label">Product Brand</label>
                <select name="product_brands" id="product_brands" class="form-select">
                    <option value="">Select a brand</option>
                    <?php
                    $select_query="Select * from `brands` ";
                    $result_select=mysqli_query($conn,$select_query);
                    while($data=mysqli_fetch_assoc($result_select)){
                        $brand_title=$data['brand_title'];
                        $brand_id=$data['brand_id'];
                        echo"<option value='$brand_id'>$brand_title</option>";
                    }
                    ?>
                </select>
            </div>
            <!-- product images -->
            <div class="mb-3">
                <label for="product_image1" class="form-label">Product Image 1</label>
                <input type="file" name="product_image1" id="product_image1" class="form-control" required="required" autocomplete="off">
            </div>
            <div class="mb-3">
                <label for="product_image2" class="form-label">Product Image 2</label>
                <input type="file" name="product_image2" id="product_image2" class="form-control" required="required" autocomplete="off">
            </div>
            <div class="mb-3">
                <label for="product_image3" class="form-label">Product Image 3</label>
                <input type="file" name="product_image3" id="product_image3" class="form-control" required="required" autocomplete="off">
            </div>
            <!-- product price -->
            <div class="mb-3">
                <label for="product_price" class="form-label">Product Price</label>
                <input type="text" name="product_price" id="product_price" class="form-control" placeholder="Enter product price" required="required" autocomplete="off">
            </div>
            <!-- submission button -->
            <div class="mb-3 text-center">
                <input type="submit" name="insert_product" id="insert_product" class="btn btn-info" value="Insert Product">
            </div>
        </form>
    </div>
</body>
</html>
