<?php
include('./includes/connect.php');
 
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
 
 
if(isset($_GET['delete_products'])){
$delete_id=$_GET['delete_products'];
$delete_query="DELETE FROM `products` WHERE product_id=$delete_id";
$result_products=mysqli_query($conn,$delete_query);
if($result_products){
    echo"<script> alert(' Products Deleted successfully')</script>";
    echo "<script>window.open('./index.php','_self')</script>";
}


}

?>