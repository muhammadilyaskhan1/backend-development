<?php
$servername="localhost";
$username="root";

$password="";
$databasename="mystore";
$conn=mysqli_connect("localhost","root","","mystore");
//  if(!$conn){
//     die('database connot connect'.mysqli_connect_error());
//  }
// else{

// echo('database can be connected ');

// }

?>