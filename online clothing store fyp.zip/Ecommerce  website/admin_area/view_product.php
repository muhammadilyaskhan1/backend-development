 <?php

  
if (!isset($_SESSION['admin_username'])) {
  echo "<script>alert('Please login first');</script>";
  header("Location: ../admin_area/adminlogin.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Advanced CSS Styling for Bootstrap Table</title>
   <!-- Bootstrap CSS -->
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
  <style>
    /* Custom CSS for table */
    .table-responsive {
      overflow-x: auto;
    }
    .table {
      border-collapse: separate;
      border-spacing: 0;
      width: 60%;
      margin: auto;
      height: 50%;
      
    }
    .table th, .table td {
      vertical-align: middle;
      text-align: center;
      font-size: 14px;
      border: 1px solid rgba(0,0,0,.1);
      padding: 10px;
    }
    .table th {
      background-color: #17a2b8;
      color: #fff;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: rgba(0,0,0,.05);
    }
    .table-bordered-mt-0 {
      margin-top: 10px;
    }
    .table th:last-child, .table td:last-child {
      white-space: nowrap;
    }
    .table th i, .table td i {
      margin-right: 2px;
    }
    .table th.actions, .table td.actions {
      width: 50px;
    }
    .table td {
      position: relative;
    }
    .table td span {
      display: none;
      position: absolute;
      top: 20%;
      left: 20%;
      transform: translate(-50%, -50%);
      background-color: rgba(0, 0, 0, 0.5);
      color: #fff;
      padding: 2px 5px;
      border-radius: 5px;
      z-index: 999;
    }
    .table td:hover span {
      display: block;
    }
    .productsviewimage{
      width:100%;
      height: auto;
      object-fit: cover;
    }
  </style>
</head>
<body>
  <div class="container">
    <h3 class="text-center text-success">All Products</h3>
    <div class="table-responsive">
      <table class="table table-bordered table-hover table-striped table-bordered-mt-0">
        <thead class="bg-info"> 
          <tr>
            <th>Product Id</th>
            <th>Product Title</th>
            <th>Product Image</th>
            <th>Product Price</th>
            <th>Total Sold</th>
            <th>Status</th>
            <th class="actions">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          include('../admin_area/includes/connect.php');
         
        $get_products="SELECT * FROM `products` ";
        $result=mysqli_query($conn,$get_products);
        $number=0;
        while($row=mysqli_fetch_assoc($result)){
              $product_id=$row['product_id'];
              $product_title=$row['product_title'];
              $product_image1=$row['product_image1'];
              $product_price=$row['product_price'];
              $status=$row['status'];
              $number++;
              ?>
              
              <tr>
            <td><?php echo $number ?></td>
            <td><?php echo $product_title ?></td>
            <td><img src='./product_images/<?php echo $product_image1 ?>' class='productsviewimage'/> </td>
            <td><?php echo $product_price?></td>
            <td>
            <?php  
            $get_count="SELECT * FROM `orders_pending` WHERE product_id	=$product_id";
              $result_querys=mysqli_query($conn, $get_count);
              $rows_count=mysqli_num_rows($result_querys);
              echo $rows_count;
              ?>
            </td>
            <td><?php  echo $status ?></td>
            <td class='actions'>
              <a href='index.php?edit_products=<?php echo $product_id ?>' class='btn btn-primary btn-sm'><i class='fas fa-edit'></i> Edit</a>
              <a href='index.php?delete_products=<?php echo $product_id ?>' class='btn btn-danger btn-sm'><i class='fas fa-trash-alt'></i> Delete</a>
            </td>
          </tr>
             <?php 
              
            

        }


          ?>
       <!-- 
         
       <tr>
                   <td>1</td>
                   <td>product title</td>
                   <td><img src=''/> </td>
                   <td></td>
                   <td>0
                   </td>
                   <td> status </td>
                   <td class='actions'>
                     <a href='#' class='btn btn-primary btn-sm'><i class='fas fa-edit'></i> Edit</a>
                     <a href='#' class='btn btn-danger btn-sm'><i class='fas fa-trash-alt'></i> Delete</a>
                   </td>
                 </tr>



           -->
          <!-- Add more rows here if needed -->
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bootstrap JS (optional) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
