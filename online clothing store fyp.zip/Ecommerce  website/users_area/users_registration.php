<?php
  include('../admin_area/includes/connect.php');
  include('../admin_area/functions/common_functions.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="../clothingstore.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
 
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="text-center ">User Registration</h2>
      <form class="registration-form" method="post" enctype="multipart/form-data">
         
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" name="user_email" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-control" id="password" name="user_password" required>
        </div>
        <div class="form-group mg-0">
          <label for="password">Confirm Password</label>
          <input type="password" class="form-control" id="password" name="confirm_password" required>
        </div>
        <div class="form-group mg-0">
          <label for="image">Image</label>
          <input type="file" class="form-control-file" id="image" name="user_image">
        </div>
        <div class="form-group mg-0">
          <label for="address">Address</label>
          <textarea class="form-control" id="address" name="user_address" rows="3" required></textarea>
        </div>
        <div class="form-group mg-o">
          <label for="mobile">Contact</label>
          <input type="tel" class="form-control" id="mobile" name="user_contact" required>
        </div>
        <input type="submit" class="btn btn-primary btn-block" name="user_register">
      </form>
    </div>
  </div>
</div>

<style>
  /* Resetting default margin and padding */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Styling the container */
.container {
  max-width: 500px;
  margin: 50px auto;
  padding: 20px;
  background-color: #7E909A;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the form header */
h2 {
  text-align: center;
  margin-bottom: 20px;
}

/* Styling the form inputs and labels */
.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="email"],
input[type="password"],
input[type="tel"],
textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

textarea {
  resize: vertical;
}

/* Styling the file input */
input[type="file"] {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #fff;
}

/* Styling the submit button */
input[type="submit"] {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

input[type="submit"]:hover {
  background-color: #0056b3;
}
</style>

<?php
if(isset($_POST['user_register'])){
  $username = $_POST['username'];
  $user_email = $_POST['user_email'];
  $user_password = $_POST['user_password'];
  $confirm_password = $_POST['confirm_password'];
  $user_address = $_POST['user_address'];
  $user_contact = $_POST['user_contact'];
  $user_image = $_FILES['user_image']['name'];  
  $user_image_tmp = $_FILES['user_image']['tmp_name'];  
  $user_ip = getIPAddress();
  
  $sql_select = "SELECT * FROM user_table WHERE username='$username' AND user_email='$user_email'";
  $result = mysqli_query($conn, $sql_select);
  $row_exists = mysqli_num_rows($result);
  
  if($row_exists > 0) {
    echo "<script>alert('Username and email already exist');</script>";
  } elseif($user_password != $confirm_password) {
    echo "<script>alert('Passwords do not match');</script>";
  } elseif(empty($username) || empty($user_contact)) {
    echo "<script>alert('Username and Contact Number are required');</script>";
  } elseif (!preg_match("/^\d{10}$/", $user_contact)) {
    echo "<script>alert('Contact number must be a valid 10-digit number');</script>";
  } else {
    move_uploaded_file($user_image_tmp, "../users_area/user_image/$user_image");
    $sql_query = "INSERT INTO user_table (username, user_email, user_password, user_address, user_contact, user_image, user_ip)
    VALUES ('$username', '$user_email', '$user_password', '$user_address', '$user_contact', '$user_image', '$user_ip')";
    $sql_execute = mysqli_query($conn, $sql_query);
    
    $select_cart_items = "SELECT * FROM `cart_details` WHERE ip_address='$user_ip'";
    $result_cart = mysqli_query($conn, $select_cart_items);
    $result_card_row = mysqli_num_rows($result_cart);
    
    if($result_card_row > 0) {
      $_SESSION['username'] = $username;
      echo "<script>alert('You have items in your cart');</script>";
      echo "<script>window.open('checkout.php','_self')</script>";
    } else {
      echo "<script>window.open('../index.php','_self')</script>";
    }
  }
}
?>

</body>
</html>
