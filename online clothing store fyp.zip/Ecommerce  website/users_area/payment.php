<?php

 
include('../admin_area/includes/connect.php');
include('../admin_area/functions/common_functions.php');
 

?>
 
 
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>payment page </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 <!-- boostrap css link--->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<style>
    img{
        width: 80%;
       margin: auto;
       display: block;
    }


</style>
 <body>
 <?php
// Assuming $conn is a valid MySQLi connection object

// Get user's IP address
$user_ip = getIPAddress();

// Query to select user based on IP address
$get_user = "SELECT * FROM `user_table` WHERE user_ip='$user_ip'";

// Execute query
$results = mysqli_query($conn, $get_user);

// Check if query executed successfully
if ($results) {
    // Fetch user data
    $run_query = mysqli_fetch_array($results);
    if ($run_query) {
        // Retrieve user ID
        $user_id = $run_query['user_id'];
        // Use user ID as needed
    } else {
        // No user found with the given IP address
        echo "No user found with the given IP address.";
    }
} else {
    // Error handling for query execution failure
    echo "Error: " . mysqli_error($conn);
}
?>


    <div class="container">
<h2 class="text-center text-info">payment option</h2>
<div class="row d-flex justify-content-center align-item-center">
<div class="col-md-6">
    <a href="https://www.paypal.com" target="_blank">
        <img src="..\images\upi-image-2-800x430.jpg" alt="">
    </a>
    </div>
    <div class="col-md-6">
    <a href="order.php?user_id=<?php echo $user_id ?>">
    <h2 class="text-center "> pay offline</h2>
 
    </a>
    </div>
</div>


    </div>
 </body>
 </html>