<?php
include('./includes/connect.php');
  
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 

if(isset($_GET['delete_brands'])){
$delete_id=$_GET['delete_brands'];
$delete_query="DELETE FROM `brands` WHERE brand_id=$delete_id";
$result_brands=mysqli_query($conn,$delete_query);
if($result_brands){
    echo"<script> alert(' Brands Deleted successfully')</script>";
    echo "<script>window.open('./index.php','_self')</script>";
}


}

?>