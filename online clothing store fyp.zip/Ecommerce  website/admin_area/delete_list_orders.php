<?php
include('./includes/connect.php');

  
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
if(isset($_GET['delete_list_orders'])){
$delete_id=$_GET[ 'delete_list_orders'];
$delete_query="DELETE FROM `user_orders` WHERE order_id=$delete_id";
$result_orders=mysqli_query($conn,$delete_query);
if($result_orders){
    echo"<script> alert(' order  Deleted successfully')</script>";
    echo "<script>window.open('./index.php','_self')</script>";
}


}

?>