<?php
include('./includes/connect.php');
 
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
 
if(isset($_GET['deletepayment'])){
$delete_payment=$_GET[ 'deletepayment'];
$delete_query="DELETE FROM `user_payments` WHERE payment_id=$delete_payment";
$result_orders=mysqli_query($conn,$delete_query);
if($result_orders){
    echo"<script> alert(' payment Deleted successfully')</script>";
    echo "<script>window.open('./index.php','_self')</script>";
}


}

?>