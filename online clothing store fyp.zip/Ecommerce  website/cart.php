<?php
include('./admin_area/includes/connect.php');
include('./admin_area/functions/common_functions.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- Font Awesome link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!-- Style CSS -->
  <link rel="stylesheet" href="clothingstore.css">
  <style>
    .cart-image {
      width: 100px;
      height: 100px;
      object-fit: contain;
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-info">
    <div class="container-fluid">
      <!-- <img src="images/download.jpg" alt="" class="logo"> -->
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="display_all.php">Products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Users_area/users_registration.php">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="cart.php"><i class="fa-solid fa-cart-plus"></i><sup>
            <?php
              cart_item();
            ?>
            </sup> </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"> Total price:<?php
              total_price_cart();
            ?>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Cart Information -->
  <?php
    cart();
  ?>

  <!-- Second Child -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
    <ul class="navbar-nav me-auto">
      <?php
        if(!isset($_SESSION['username'])){
          echo "<li class='nav-item'>
                  <a class='nav-link' href='#'>Welcome Guest</a>
                </li>";
        } else {
          echo "<li class='nav-item'>
                  <a class='nav-link' href='#'>Welcome ".$_SESSION['username']."</a>
                </li>";
        }
        
        if(!isset($_SESSION['username'])){
          echo "<li class='nav-item'>
                  <a class='nav-link' href='./Users_area/user_login.php'>Login</a>
                </li>";
        } else {
          echo "<li class='nav-item'>
                  <a class='nav-link' href='./Users_area/logout.php'>Logout</a>
                </li>";
        }
      ?>
    </ul>
  </nav>
  <!-- <div class="hiddenstore">
    <h3 class="text-center"> ONLINE CLOTHING WEBSITE</h3>
    <p class="text-center"> this website static </p>
  </div> -->
  <div class="container p-2">
    <div class="row">
      <div class="col">
        <form action="" method="post"> 
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th>Product Title</th>
                  <th>Image</th>
                  <th>Quantity</th>
                  <th>Total Price</th>
                  <th>Remove</th>
                  <th colspan="2">Operations</th>
                </tr>
              </thead>
              <tbody>
                <?php
            
                  global $conn;
                  $get_ip_add= getIPAddress();
                
                  $total_price=0;
                 
                   
                  $sql = "SELECT * FROM `cart_details` WHERE ip_address='$get_ip_add'";
                  $result_cards = mysqli_query($conn, $sql);
                  $result_count=mysqli_num_rows($result_cards);
                  if($result_count>0){
                    while ($row = mysqli_fetch_array($result_cards)) {
                      $product_id = $row['product_id'];
                      $select_query = "SELECT * FROM `products` WHERE product_id='$product_id'";
                      $result_query = mysqli_query($conn, $select_query);
                      while ($row_product_price= mysqli_fetch_array($result_query)) {
                        $product_price = $row_product_price['product_price'];
                        $price_tabale=$row_product_price['product_price'];
                        $product_title=$row_product_price['product_title'];
                        $product_image1=$row_product_price['product_image1'];
                        
                        $total_price+= $product_price;
                       
                ?>
                <tr>
                  <td><?php echo $product_title ?></td>
                  <td><img src="./admin_area/product_images/<?php echo $product_image1?>" class="cart-image" alt=""></td>
                  <td><input type="number" class="form-input" name="qty" value="<?php echo $row['quantity'] ?>"></td>
 

                  <?php
                 $get_ip_add= getIPAddress();  
if(isset($_POST['update_cart'])){
$quantities=$_POST['qty'];
$update_cart="UPDATE `cart_details` SET quantity=$quantities WHERE ip_address='$get_ip_add' ";
$result_product_quantites=mysqli_query($conn,$update_cart);
$total_price =$total_price*$quantities;
 
}

 



?>

 
<td><?php echo $price_tabale ?></td>
                  <td><input type="checkbox" name="removeitem[]" value="<?php echo $product_id ?>"></td>
                 <td> 
                <button type="submit" name="update_cart" class="btn btn-primary me-2">
                    <i class="fas fa-sync-alt me-1"></i> Update Cart
                </button>
                <button type="submit" name="remove_cart" class="btn btn-danger">
                    <i class="fas fa-trash-alt me-1"></i> Remove Cart
                </button>
                </td> 
          </tr>
                <?php
                      }
                    }
                  } else {
                    echo "<h1 class='text-center'>Cart is empty</h1>";
                  }
                
       ?>




              </tbody>
            </table>
          </div>
        </form>

     
        <?php 
          function remove_cart_item(){
            global $conn;
            if(isset($_POST['remove_cart']) && isset($_POST['removeitem'])){
              foreach ($_POST['removeitem'] as $remove_id){ 
                $delete_query="DELETE FROM `cart_details` WHERE product_id='$remove_id'";
                $run_delete=mysqli_query($conn,$delete_query);
                if($run_delete){
                  echo "<script>window.open('cart.php','_self')</script>";
                }
              }
            }
          }
          echo $remove_item= remove_cart_item();
        ?>
        <div> 

<?php
    $sql = "SELECT * FROM `cart_details` WHERE ip_address='$get_ip_add'";
    $result_cards = mysqli_query($conn, $sql);
    $result_count = mysqli_num_rows($result_cards);
    if ($result_count > 0) {
        ?>
        <div class="">
            <h4 class="">Subtotal: <strong class="text-primary"><?php echo $total_price;?></strong></h4>
        </div>
       
        <div class="d-flex" id="paymentandcontinousbutton">
    <a href="index.php" class="btn btn-info btn-lg"><i class="fas fa-shopping-cart me-3"></i>Continue Shopping</a>
    <a href="./users_area/checkout.php" class="btn btn-secondary btn-lg"><i class="fas fa-money-bill-wave me-3"></i>Checkout</a>
 
</div>

    <?php
    } else {
        ?>
        <div class="">
        <a href="index.php" class="btn btn-info btn-lg"><i class="fas fa-shopping-cart me-3"></i>Continue Shopping</a>
         
        </div>
    <?php
    }
?>
</div>

        </div>
      </div>
    </div>
  </div>

 

<style>

  /* Styling the table */
.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
  height: 180px
}

/* Styling the table header */
.table thead th {
  background-color: #343a40;
  color: #fff;
  border: 1px solid #dee2e6;
  padding: 4px;
  text-align: center;
}

/* Styling the table body */
.table tbody td {
  border: 1px solid #dee2e6;
  padding: 8px;
}

/* Styling table rows */
/* .table tbody tr:nth-child(even) {
  background-color: gray;
} */

/* Styling table row hover effect */
/* .table tbody tr:hover {
  background-color:gray;
} */

/* Styling the form input within the table */
.table .form-input {
  width: 50px; /* Adjust as needed */
  text-align: center;
}

/* Styling the cart image within the table */
.table .cart-image {
  width: 100%; /* Adjust as needed */
  height:300px
  object-fit: cover;
}

/* Styling the buttons within the table */
.table .btn-space {
  margin-right: 5px;
  
}
#paymentandcontinousbutton{
    gap: 20px;
}






</style>
  <!-- Bootstrap JS -->
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
</body>

</html>
