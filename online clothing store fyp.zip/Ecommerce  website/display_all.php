<?php
  include('./admin_area/includes/connect.php');

 include('./admin_area/functions/common_functions.php');
 session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width= device-width, initial-scale=1.0">
  <title>ONLINE CLOTHING WEBSITE</title>
  <link rel="stylesheet" href="clothingstore.css">
  <!-- boostrap css link--->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!---font awosome link---->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <!---stylecss--->
 
</head>

<body>
 
  <!---- navbar---->
  <nav class="navbar navbar-expand-lg navbar-light bg-info">
    <div class="container-fluid">
      <!-- <a class="navbar-brand" href="#">logo</a> -->
      <!-- <img src="" alt="" class="logo"> -->
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="display_all.php">products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Users_area/users_registration.php">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="cart.php"><i class="fa-solid fa-cart-plus"></i><sup>
             <?php

              cart_item();

              ?>


            </sup> </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Total price:<?php
            total_price_cart();
            
            ?>/-</a>
          </li>

        </ul>
        <form class="d-flex" action="search_product.php" method="get">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"name="search_data">
       <!--  <button></button>--->
       <input type="submit" value="search" class="btn btn-outline-light" name="search_data_product">
        </form>

      </div>
    </div>
  </nav>
  <!-- second child -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
    <ul class="navbar-nav me-auto">
      <!-- <li class="nav-item">
        <a class="nav-link" href="#">welcome guest</a>
      </li> -->
      <?php
 
if(!isset($_SESSION['username'])){
  echo" <li class='nav-item'>
  <a class='nav-link' href='#'>welcome guest </a>
</li> 

  ";
 
}
else{
  echo"<li class='nav-item'>
        <a class='nav-link' href='#'>welcome ".$_SESSION['username']."</a></li>

  ";
}
 



if(!isset($_SESSION['username'])){
  echo"
  <li class='nav-item'>
        <a class='nav-link' href='./Users_area/user_login.php'>login</a></li>

  ";
 
}
else{
  echo"<li class='nav-item'>
        <a class='nav-link' href='./Users_area/logout.php'>logout</a></li>

  ";
}
?>
      <!-- <li class="nav-item">
        <a class="nav-link" href="Users_area/user_login.php">login</a>
      </li> -->

    </ul>
  </nav>
  <div class="hiddenstore">
    <h3 class="text-center"> ONLINE CLOTHING WEBSITE</h3>
 
  </div>
<!---calling function in php --->
<?php
cart();
  ?>




  <!-- products -->
  <div class="row">
    <div class="col-md-10">
      <!-- giveproducttable and add product data -->
      <div class="row">

<!-- fetching products -->
<?php 
//  getproducts();
display_allproduct();
 get_unique_categories();
 get_unique_brands();
 
// agar item ko order yane rand karna chatay ho tu is kay leya order by lekna hay ya rand()
// limit use hota hay ka aap home page may ketnay product daykna chatay ho
// is ko hom function may be karsaktay hay
// $sql="SELECT * FROM `products` order by rand() LIMIT 0,9 ";
// $result=mysqli_query($conn,$sql);
//  while($row=mysqli_fetch_array($result)){
//   $product_id =$row['product_id'];
//   $product_title =$row['product_title'];
//   $product_description = $row['product_description'];
//   //$product_keyword = $row['product_keyword']; zarurat nahe hay date our status ke be zarurat nahe hay 
//   $product_category =$row['category_id'];
//   $product_brands = $row['brand_id']; 
//   $product_image1 = $row['product_image1'];
//   //$product_status = 'true'; is ke zarurat nahe hay
//   //echo $product_description;
//   echo"
//   <div class='col-md-4 mb-2'>
//   <div class='card'>
//   <img class='card-img-top' src='.\admin_area\product_images/$product_image1' alt='Card image cap'>
//   <div class='card-body'>
//     <h5 class='card-title'>$product_title</h5>
//     <p class='card-text'> $product_description</p>
//     <a href='#' class='btn btn-info'>Add to Card</a>
//     <a href='#' class='btn btn-secondary'>view more</a>
//   </div>
// </div>
//   </div>
//   ";}
 

?>
        <!-- <div class="col-md-4 mb-2">
          <div class="card">
            <img class="card-img-top" src="images/images.jpg" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's
                content.</p>
              <a href="#" class="btn btn-info">Add to Card</a>
              <a href="#" class="btn btn-secondary">view more</a>
            </div>
          </div>
        </div> -->
        <!--  this card is static working only using in frontend development
              <div class="col-md-4 mb-2">
           <div class="card">
      <img class="card-img-top" src="images/images (1).jpg" alt="Card image cap">
      <div class="card-body">
        <h5 class="card-title">Card title</h5>
         <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
         <a href="#" class="btn btn-info">Add to Card</a>
         <a href="#" class="btn btn-secondary">view more</a>
            </div>
       </div>
       </div> -->
       
               <!-- <div class="col-md-4 mb-2">
       <div class="card">
         <img class="card-img-top" src="images/images (2).jpg" alt="Card image cap">
         <div class="card-body">
           <h5 class="card-title">Card title</h5>
           <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
           <a href="#" class="btn btn-info">Add to Card</a>
           <a href="#" class="btn btn-secondary">view more</a>
         </div>
             </div>
             </div> -->
             
             
                     <!---- card-- continous static-->
             <!-- card end boostrap -->
                   </div>
<!--row end -->
    </div>
  


    <div class="col-md-2 bg-secondary">
      <ul class="navbar-nav me-auto p*2 text-center">
        <li class="nav-item bg-info">
          <a href="#" class="nav-link text-light">
            <h4>Dilivery Brands</h4>
          </a>
        </li>
        <?php

getbrands();

//         $sql = "SELECT * FROM `brands`";
//         $select_brand = mysqli_query($conn, $sql);
//         $row_brand = mysqli_num_rows($select_brand);
//         //$data=mysqli_fetch_assoc($select_brand);
// // echo $data['brand_title'];
//         while ($data = mysqli_fetch_assoc($select_brand)) {
//           $brand_title = $data['brand_title'];
//           $brand_id = $data['brand_id'];
//           //echo $brand_title,$brand_id;
//           echo "<li class='nav-item '>
// <a href='index.php?brand=$brand_id' class='nav-link text-light'>$brand_title  </a>
// </li>";
//         }


        ?>



        <!-- <li class="nav-item ">
        <a href="#" class="nav-link text-light" > brand1</a>
        </li>
        <li class="nav-item ">
        <a href="#" class="nav-link text-light" > Brands2</a>
        </li>
        <li class="nav-item">
        <a href="#" class="nav-link text-light" >  Brands3</a>
        </li> -->



      </ul>
      <ul class="navbar-nav me-autop*2 text-center">
        <li class="nav-item bg-info">
          <a href="#" class="nav-link text-light">
            <h4> category</h4>
          </a>
        </li>

        <?php
getcategories();
 


// $sql = "SELECT * FROM `category`";
// $select_category = mysqli_query($conn, $sql);
// $row_category = mysqli_num_rows($select_category);
// //$data=mysqli_fetch_assoc($select_brand);
// // echo $data['category_title'];
// while ($data = mysqli_fetch_assoc($select_category)) {
//   $category_id = $data['category_id'];
//   $category_title = $data['category_title'];

//   //echo $category_title,$category_id;
//   echo "<li class='nav-item '>
// <a href='index.php?category=$category_id' class='nav-link text-light'>$category_title  </a>
// </li>";
// }



        ?>

        <!--  
        <li class="nav-item ">
        <a href="#" class="nav-link text-light" >  category1</a> 
        </li>
        <li class="nav-item ">
        <a href="#" class="nav-link text-light" > category2</a>
        </li>
        <li class="nav-item">
        <a href="#" class="nav-link text-light" >category3</a>
        </li> -->

      </ul>





    </div>
    <!-- colums end -->
    </div>



  <!--last child--->

  <!-- this is a footer -->
  <!-- <div class="bg-info p-3 text-center">
    <p> All right reversed design by muhammad ilyas @2024</p>
  </div> -->
 






















  <!--boostrap js link---->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
</body>

</html>