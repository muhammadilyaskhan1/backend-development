<?php
include('../admin_area/includes/connect.php');
include('../admin_area/functions/common_functions.php');

// Check if user_id is set in the URL
if(isset($_GET['user_id'])){
    $user_id = $_GET['user_id'];
    
    // Get the user's IP address
    $get_ip_add = getIPAddress();
    $total_price = 0;
    $count_product = 0;
    $invoice_number = rand(); // Generate a random invoice number
    $status = 'pending';

    // SQL query to select items in the cart based on user's IP address
    $sql = "SELECT * FROM `cart_details` WHERE ip_address='$get_ip_add'";
    $result_cards = mysqli_query($conn, $sql);

    // Check if any cart items are found
    if($result_cards) {
        // Iterate over cart items
        while ($row = mysqli_fetch_array($result_cards)) {
            $product_id = $row['product_id'];
            $quantity = $row['quantity']; // Assuming quantity field is in cart_details table
            
            // Fetch product details from products table
            $select_query = "SELECT * FROM `products` WHERE product_id='$product_id'";
            $result_query = mysqli_query($conn, $select_query);
            
            // Check if the product details are found
            if ($result_query) {
                // Iterate over product details
                while ($row_product_price = mysqli_fetch_array($result_query)) {
                    $product_price = $row_product_price['product_price'];
                    $total_price += $product_price * $quantity; // Calculate total price based on quantity
                }
            }
            
            $count_product++; // Increment count of products
        }
    }
    
    // Insert order into database
    $insert_orders = "INSERT INTO `user_orders`(`user_id`, `amount_due`, `invoice_number`, `total_products`, `order_status`, `order_date`) VALUES('$user_id', '$total_price', '$invoice_number', '$count_product', '$status', NOW())";
    $result_order = mysqli_query($conn, $insert_orders);
    $order_id = mysqli_insert_id($conn); // Get the last inserted order id
    
    // Check if the order was inserted successfully
    if($result_order){
        // Insert each product into the orders_pending table
        $result_cards = mysqli_query($conn, $sql); // Re-execute the cart details query
        while ($row = mysqli_fetch_array($result_cards)) {
            $product_id = $row['product_id'];
            $quantity = $row['quantity'];
            $insert_pending_orders = "INSERT INTO `orders_pending` (order_id, user_id, invoice_number, product_id, quantity, order_status) VALUES ('$order_id', '$user_id', '$invoice_number', '$product_id', '$quantity', '$status')";
            mysqli_query($conn, $insert_pending_orders);
        }

        // Clear the cart
        $empty_cart = "DELETE FROM `cart_details` WHERE ip_address='$get_ip_add'";
        $result_cart_delete = mysqli_query($conn, $empty_cart);

        echo "<script>alert('Order submitted successfully')</script>";
        echo "<script>window.location.href = 'profile.php';</script>";
    } else {
        echo "<script>alert('Error submitting order: ". mysqli_error($conn) ."')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Submission</title>
</head>
<body>
    <!-- HTML content -->
</body>
</html>
