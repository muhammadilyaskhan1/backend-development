<?php
include('../admin_area/includes/connect.php');
include('../admin_area/functions/common_functions.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Registration</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
 
<style>
  /* Resetting default margin and padding */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Styling the container */
.container {
  max-width: 500px;
  margin: 50px auto;
  padding: 20px;
  background-color: #7E909A;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Styling the form header */
h2 {
  text-align: center;
  margin-bottom: 20px;
}

/* Styling the form inputs and labels */
.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input[type="text"],
input[type="email"],
input[type="password"],
input[type="tel"],
textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

textarea {
  resize: vertical;
}

/* Styling the file input */
input[type="file"] {
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #fff;
}

/* Styling the submit button */
input[type="submit"] {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

input[type="submit"]:hover {
  background-color: #0056b3;
}
</style>
  

</style>
</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h2 class="text-center">Admin Registration</h2>
      <form class="registration-form" method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" class="form-control" id="username" name="admin_username" required>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" name="admin_email" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" class="form-control" id="password" name="admin_password" required>
        </div>
        <div class="form-group">
          <label for="confirm_password">Confirm Password</label>
          <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
        </div>
        <input type="submit" class="btn btn-primary btn-block" name="admin_register">
      </form>
    </div>
  </div>
</div>

<?php
if (isset($_POST['admin_register'])) {
    $admin_username = $_POST['admin_username'];
    $admin_email = $_POST['admin_email'];
    $admin_password = $_POST['admin_password'];
    $confirm_password = $_POST['confirm_password'];

    $sql_select = "SELECT * FROM `admin` WHERE admin_username='$admin_username' AND admin_email='$admin_email'";
    $result = mysqli_query($conn, $sql_select);
    $row_exists = mysqli_num_rows($result);

    if ($row_exists > 0) {
        echo "<script>alert('Username and email already exist');</script>";
    } elseif ($admin_password != $confirm_password) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
        $sql_query = "INSERT INTO `admin` (admin_username, admin_email, admin_password) VALUES ('$admin_username', '$admin_email', '$hashed_password')";
        $sql_execute = mysqli_query($conn, $sql_query);
        if ($sql_execute) {
          echo "<script>alert('Registration successful'); window.location.href = '../admin_area/adminlogin.php';</script>";
      }
      else {
            echo "<script>alert('Error in registration');</script>";
        }
    }
}
?>

</body>
</html>
 