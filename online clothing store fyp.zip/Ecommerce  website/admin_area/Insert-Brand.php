<?php
include('./includes/connect.php');
  
if (!isset($_SESSION['admin_username'])) {
  echo "<script>alert('Please login first');</script>";
  header("Location: ../admin_area/adminlogin.php");
  exit();
}

 
  if(isset($_POST['insert_brand'])){
    $brand_title	=$_POST['brand_title'];
    //select data from database
   $select_query="SELECT * FROM `brands`WHERE brand_title='$brand_title'";
   $result_select=mysqli_query($conn,$select_query);
$number=mysqli_num_rows($result_select);
if($number>0){
  echo"<script>alert(' this category is present inside database')   </script> ";
}
else{
    $insert_query="INSERT INTO `brands`(brand_title)VALUES('$brand_title')";
     $result=mysqli_query($conn,$insert_query);
     if($result>0){
      echo"<script>alert('category has been add successfully')   </script> ";
     }
    }
   }
    
  
?>



<h2 class="text-center">insert  brands</h2>
<form action="" method="post" class="mb-2">
<div class="input-group mb-0 w*90" >
  <span class="input-group-text" id="basic-addon1 bg-info" ><i class="fa-solid fa-receipt"></i></span>
  <input type="text" class="form-control" name="brand_title" placeholder="Insert brand" aria-label="Username" aria-describedby="basic-addon1">
</div>
<div class="input-group mb-2 w*10">
 
  <!-- <input type="submit" class="form-control bg-info" name="insert-cat" placeholder=" Insert categories" aria-label="Username" aria-describedby="basic-addon1" value="Insert categories"> -->
  <button name="insert_brand"class="bg-info p-4 border-0 my-3" >Insert brand</button>
</div>
 
</form>
<style>

  /* Form Styles */
form {
  max-width: 400px; /* Adjust form width */
  margin: 0 auto;
}

.input-group {
  margin-bottom: 15px; /* Adjust spacing between input groups */
}

.input-group-text {
  background-color: #17a2b8; /* Input group text background color */
  color: #fff; /* Input group text color */
}

.input-group input {
  border-radius: 0; /* Remove border-radius for input */
}

.input-group button {
  border-radius: 0; /* Remove border-radius for button */
  cursor: pointer;
}

/* Button Styles */
input[type="submit"],
button {
  background-color: #17a2b8; /* Button background color */
  color: #fff; /* Button text color */
  border: none;
  padding: 10px 20px; /* Adjust button padding */
}

input[type="submit"]:hover,
button:hover {
  background-color: #117a8b; /* Button background color on hover */
}

/* Responsive Styles */
@media (max-width: 576px) {
  form {
    max-width: 90%; /* Adjust form width for smaller screens */
  }
  
  .input-group {
    display: block;
    width: 100%;
  }
  
  .input-group input {
    width: calc(100% - 40px); /* Adjust input width */
  }
  
  .input-group button {
    width: 100%; /* Make button full-width */
  }
}

</style>