<?php
  include('../admin_area/includes/connect.php');
 session_start();
   ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width= device-width, initial-scale=1.0">
  <title>Ecommerce website using php and mysql</title>
  <!-- boostrap css link--->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!---font awosome link---->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <!---stylecss--->
  <link rel="stylesheet" href="../clothingstore.css">
</head>

<body>
  <!---- navbar---->
  <nav class="navbar navbar-expand-lg navbar-light bg-info">
    <div class="container-fluid">
      <!-- <a class="navbar-brand" href="#">logo</a> -->
      <img src="images/download.jpg" alt="" class="logo">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="../index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../display_all.php">products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Users_area/users_registration.php">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../contact.php">Contact</a>
          </li>


          </a>
          </li>

        </ul>
        <form class="d-flex " action="../search_product.php" method="get">
          <input class="form-control  me-2  " type="search" placeholder="Search" aria-label="Search" name="search_data">
          <!--  <button></button>--->
          <input type="submit" class="btn btn-outline-light" name="search_data_product">
        </form>
      </div>
    </div>
  </nav>
   



  <!-- second child -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-secondary ">
    <ul class="navbar-nav me-auto" id="welcomeguest">
      <!-- <li class="nav-item">
        <a class="nav-link" href="#">welcome guest</a>
      </li> -->
      <?php
   
if(!isset($_SESSION['username'])){
  echo" <li class='nav-item'>
  <a class='nav-link' href='#'>welcome guest </a>
</li> 

  ";
 
}
else{
  echo"<li class='nav-item'>
        <a class='nav-link' href='#'>welcome ".$_SESSION['username']."</a></li>

  ";
}
 
if(!isset($_SESSION['username'])){
  echo"
  <li class='nav-item'>
        <a class='nav-link' href='user_login.php'>login</a></li>

  ";
 
}
else{
  echo"<li class='nav-item'>
        <a class='nav-link' href='./Users_area/logout.php'>logout</a></li>

  ";
}
?>
      <!-- <li class="nav-item">
        <a class="nav-link" href="#">login</a>
      </li> -->

    </ul>
  </nav>
   

 
  <!-- products -->
  <div class="row">
    <div class="col-md-10">
      <!-- giveproducttable and add product data -->
      <div class="row">
<?php

if(!isset($_SESSION['username'])){
include('../users_area/user_login.php');
}
else{
  include('payment.php');
}








?>
       </div>
    </div>
  </div>
  <!-- colums end -->
  </div>



  <!--last child--->

   




<style>

 /* Navbar Styles */
 .navbar{
  background-color: #7E909A; /* Navbar background color */
}

.navbar-brand{
  padding: 0; /* Remove padding from the brand */
}

.navbar-brand img.logo{
  width: 50px; /* Adjust logo width */
  height: auto; /* Maintain aspect ratio */
}

.navbar-toggler{
  border: none; /* Remove default border */
}

.navbar-toggler-icon {
  background-color: #202020; /* Toggler icon color */
}

.navbar-nav .nav-link{
  color: #202020; /* Navbar link color */
}

.navbar-nav .nav-link.active{
  font-weight: bold; /* Style for active navbar link */
}

.navbar-nav .nav-link i{
  margin-right: 5px; /* Adjust margin between icon and text in navbar */
}

/* Responsive Navbar */
@media (max-width: 768px){
  .navbar-nav .nav-link{
    padding: 10px; /* Adjust link padding for smaller screens */
  }
}

/* Search Form Styles */
 /* Style for search form */
.d-flex {
  display: flex;
  align-items: center;
}

.form-control {
  border: 2px solid #ccc;
  border-radius: 5px;
  padding: 8px 12px;
  font-size: 16px;
  margin-right: 10px;
}

.btn {
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn:hover {
  background-color: #0056b3;
}

/* Responsive adjustments */
@media (max-width: 576px) {
  .form-control {
    width: 100%;
    margin-right: 0;
  }
}

 #welcomeguest{
  margin: auto;
 }
 
 

.navbar {
  background-color: #2c3e50;
  padding: 10px;
  border-radius: 5px;
}

.navbar-nav {
  display: flex;
  
  justify-content: flex-end;
}

.nav-item {
  margin-left: 15px;
}

.nav-link {
  color: #fff;
  text-decoration: none;
  transition: color 0.3s ease;
}

.nav-link:hover {
  color: #3498db;
}



 
.hiddenstore{
  background-color: #CED2CC; /* Light background color */
  padding: 20px; /* Add some padding */
  margin-bottom: 10px;
  border-radius: 10px; /* Add rounded corners */
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Add a subtle shadow */
}

.text-center {
  text-align: center; /* Center align text */
  margin-bottom: 10px; /* Add some space below the text */
}

h3{
  color: #0091D5; /* Heading color */
  font-size: 24px; /* Heading font size */
  margin-top: 0; /* Remove top margin */
}

p{
  color: #0091D5; /* Paragraph text color */
  font-size: 18px; /* Paragraph font size */
  margin-bottom: 0; /* Remove bottom margin */
}







/*css code for category and brands section*/

/* Navbar Styles */
.col-md-2 {
  padding: 0; /* Remove default padding */
}

.navbar-nav {
  padding: 0; /* Remove default padding */
}

.navbar-nav .nav-item {
  margin-bottom: 5px; /* Add margin between navbar items */
}

.navbar-nav .nav-item .nav-link {
  padding: 10px; /* Add padding to navbar links */
}

.navbar-nav .nav-item.bg-info {
  background-color: #17a2b8; /* Background color for navbar item */
}

.navbar-nav .nav-item .nav-link h4 {
  margin: 0; /* Remove margin for h4 inside navbar link */
}

.navbar-nav .nav-item .nav-link {
  color: #fff; /* Text color for navbar links */
}

.navbar-nav .nav-item .nav-link:hover {
  background-color: #13545a; /* Background color on hover */
}

/* Optional: Add more styles as needed */



.footer{
  background-color: red; /* Background color */
  padding: 20px; /* Padding around content */
  color: #fff; /* Text color */
  margin-bottom: 0px;
  font-size: 16px; /* Font size */
  text-align: center; /* Center align text */
  border-top: 2px solid #0b6e82; /* Add a top border */
}

.footer p {
    /* Remove default margin for paragraph */
}

.footer a {
  color: #fff; /* Link color */
  text-decoration: none; /* Remove underline */
}

.footer a:hover {
  text-decoration: underline; /* Add underline on hover */
}

 
 




</style>






 


  <!--boostrap js link---->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
    crossorigin="anonymous"></script>
</body>

</html>