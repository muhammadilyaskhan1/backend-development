 <?php

if (!isset($_SESSION['admin_username'])) {
  echo "<script>alert('Please login first');</script>";
  header("Location: ../admin_area/adminlogin.php");
  exit();
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Advanced CSS Styling for Bootstrap Table</title>
   <!-- Bootstrap CSS -->
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
  <style>
    /* Custom CSS for table */
    .table-responsive {
      overflow-x: auto;
    }
    .table {
      border-collapse: separate;
      border-spacing: 0;
      width: 80%;
      margin: auto;
      height: 50%;
      
    }
    .table th, .table td {
      vertical-align: middle;
      text-align: center;
      font-size: 14px;
      border: 1px solid rgba(0,0,0,.1);
      padding: 10px;
    }
    .table th {
      background-color: #17a2b8;
      color: #fff;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: rgba(0,0,0,.05);
    }
    .table-bordered-mt-0 {
      margin-top: 10px;
    }
    .table th:last-child, .table td:last-child {
      white-space: nowrap;
    }
    .table th i, .table td i {
      margin-right: 2px;
    }
    .table th.actions, .table td.actions {
      width: 50px;
    }
    .table td {
      position: relative;
    }
    .table td span {
      display: none;
      position: absolute;
      top: 20%;
      left: 20%;
      transform: translate(-50%, -50%);
      background-color: rgba(0, 0, 0, 0.5);
      color: #fff;
      padding: 2px 5px;
      border-radius: 5px;
      z-index: 999;
    }
    .table td:hover span {
      display: block;
    }
    .productsviewimage{
      width: 200px;
      height: 300px;
      object-fit: cover;
    }
    img{
      width: 100%;
      object-fit: cover;
      height: auto;
    }
  </style>
</head>
<body>
  <div class="container">
  <h2 class="text-center text-success">All User</h2>
    <div class="table-responsive">
      <table class="table table-bordered table-hover table-striped table-bordered-mt-0">
        <thead class="bg-info"> 
          <tr>
            <th>user_id</th>
            <th>username</th>
            <th>user_email</th>
            <th>user_password</th>
            <th>user_image</th>
            <th>user_Address</th>
            <th>user_contact</th>
            <th class='actions'>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php
          include('../admin_area/includes/connect.php');
          $get_userlist = "SELECT * FROM `user_table` ";
          $results= mysqli_query($conn, $get_userlist);
          $row_count= mysqli_num_rows($results);
             
          if ($row_count == 0) {
            echo "<tr><td colspan='7'><h2 class='bg-danger text-center mt-5'>No user  yet</h2></td></tr>";
          } else {
 
            while ($row_data = mysqli_fetch_assoc($results)) {
              $user_id = $row_data['user_id'];
              $username = $row_data['username'];
              $user_email= $row_data['user_email'];
              $user_password = $row_data['user_password'];
              $user_image = $row_data['user_image'];
              $user_address = $row_data['user_address'];
              $user_contact = $row_data['user_contact'];
 
      
              echo "
                <tr>
                  <td> $user_id</td>
                  <td>  $username </td>
                  <td>   $user_email</td>
                  <td>     $user_password</td>
                  <td><img src='../users_area/user_image/$user_image'> </td>
                  <td>      $user_address</td>
                  <td> $user_contact </td>
                  <td class='actions'>
                    <a href='index.php?deletelist_user=$user_id' class='btn btn-danger btn-sm'><i class='fas fa-trash-alt'></i> Delete</a>
                  </td>
                </tr>";
            }
          }
        ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bootstrap JS (optional) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
