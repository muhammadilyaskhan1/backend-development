<?php
 
include('./includes/connect.php');

// Check if connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Category</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* Custom CSS for table */
        #viewcate {
            text-align: center;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 60%;
            margin: auto;
            height: 50%;

        }

        .table th,
        .table td {
            vertical-align: middle;
            text-align: center;
            font-size: 14px;
            border: 1px solid rgba(0, 0, 0, .1);
            padding: 10px;
        }

        .table th {
            background-color: #17a2b8;
            color: #fff;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, .05);
        }

        .table-bordered-mt-0 {
            margin-top: 10px;
        }

        .table th:last-child,
        .table td:last-child {
            white-space: nowrap;
        }

        .table th i,
        .table td i {
            margin-right: 2px;
        }

        .table th.actions,
        .table td.actions {
            width: 50px;
        }

        .table td {
            position: relative;
        }

        .table td span {
            display: none;
            position: absolute;
            top: 20%;
            left: 20%;
            transform: translate(-50%, -50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            padding: 2px 5px;
            border-radius: 5px;
            z-index: 999;
        }

        .table td:hover span {
            display: block;
        }

        .productsviewimage {
            width: 200px;
            height: 300px;
            object-fit: cover;
        }
    </style>
</head>
<body>
<div class="container">
    <h3 class="text-center text-success" id="viewcate">View Category</h3>
    <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped table-bordered-mt-0">
            <thead class="bg-info">
            <tr>
                <th>SLno</th>
                <th>Category Title</th>
                <th class="actions">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $get_category_query = "SELECT * FROM `category`";
            $stmt = mysqli_prepare($conn, $get_category_query);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $number = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $category_id = $row['category_id'];
                $category_title = $row['category_title'];
                $number++;
                ?>
                <tr>
                    <td><?php echo $number ?></td>
                    <td><?php echo htmlspecialchars($category_title) ?></td>
                    <td class='actions'>
                        <a href='index.php?edit_category=<?php echo $category_id ?>' class='btn btn-primary btn-sm'><i
                                    class='fas fa-edit'></i> Edit</a>
                        <a href='index.php?delete_category=<?php echo $category_id ?>'
                           class='btn btn-danger btn-sm'><i class='fas fa-trash-alt'></i> Delete</a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS (optional) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
