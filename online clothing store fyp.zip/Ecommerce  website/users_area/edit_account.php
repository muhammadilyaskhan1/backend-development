<?php
  include('../admin_area/includes/connect.php');
if(isset($_GET['edit_account'])){
    $user_session_name=$_SESSION['username'];
    $sql_select=" SELECT * FROM user_table WHERE username='$user_session_name'";
$result=mysqli_query($conn,$sql_select);
 $row_fetch=mysqli_fetch_assoc($result);
 $user_id =$row_fetch['user_id'];
 $username =$row_fetch['username'];
 $user_email = $row_fetch['user_email'];
 $user_address = $row_fetch['user_address'];
 $user_contact = $row_fetch['user_contact'];
 
} 

if(isset($_POST['user_update'])){
    $update_id = $user_id; // Assuming user_id is coming from the form
    $username = $_POST['username'];
    $user_email = $_POST['user_email'];
    $user_address = $_POST['user_address'];
    $user_contact = $_POST['user_contact'];
    
    // File upload handling
    $user_image = $_FILES['user_image']['name'];  
    $user_image_tmp = $_FILES['user_image']['tmp_name'];
    move_uploaded_file($user_image_tmp, "../users_area/user_image/$user_image");
    
    // Construct the SQL query
    $sql_select = "UPDATE `user_table` SET `username`='$username', `user_email`='$user_email', `user_image`='$user_image', `user_address`='$user_address', `user_contact`='$user_contact' WHERE `user_id`='$update_id'";
    
    // Execute the SQL query
    $result_query_update = mysqli_query($conn, $sql_select);
    
    // Check if the update was successful
    if($result_query_update){
        echo "<script> alert('Data updated successfully')</script>";
        echo "<script> window.open('logout.php','_self')</script>";
    } else {
        echo "error";
    }
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit account </title>
</head>
 
<body>
    <h3 class=" text-center text-success mb-4">Edit account</h3>
    <form action="" method="post" enctype="multipart/form-data" class="text-center">
<div class="form-outline mb-4">
<input type="text" class=" form-control w-50 m-auto" name="username" value="<?php echo $username?>">
</div>

<div class="form-outline mb-4">
<input type="email" class=" form-control w-50 m-auto"  name="user_email" value="<?php echo $user_email?>">
</div>
<div class="form-outline mb-4 d-flex w-50 m-auto">
<input type="file" class=" form-control "  name="user_image">
<img src="./user_image/<?php echo $user_image?>" class="profile_image" alt="">
</div>

<div class="form-outline mb-4">
<input type="text" class=" form-control w-50 m-auto"  name="user_address" value="<?php echo $user_address?>">
</div>
<div class="form-outline mb-4">
<input type="number" class=" form-control w-50 m-auto"  name="user_contact" value="<?php echo $user_contact?>">
</div>
<input type="submit" name="user_update" id="" value="Update" class="bg-info py-2 px-3 border-0">
    </form>



    <style>
   .profile_image{
width: 200px;
height: 20%;
 object-fit: contain;
}
</style>
</body>
</html>