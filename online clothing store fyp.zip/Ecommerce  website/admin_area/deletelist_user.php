<?php
include('./includes/connect.php');
 
if (!isset($_SESSION['admin_username'])) {
    echo "<script>alert('Please login first');</script>";
    header("Location: ../admin_area/adminlogin.php");
    exit();
  }
 
 
if(isset($_GET['deletelist_user'])){
$delete_user=$_GET[ 'deletelist_user'];
$delete_query="DELETE FROM `user_table` WHERE user_id=$delete_user";
$result_orders=mysqli_query($conn,$delete_query);
if($result_orders){
    echo"<script> alert('User list Deleted successfully')</script>";
    echo "<script>window.open('./index.php','_self')</script>";
}


}

?>