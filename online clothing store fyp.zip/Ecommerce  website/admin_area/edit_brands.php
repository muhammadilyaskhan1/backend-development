<?php
include('../admin_area/includes/connect.php');
  
if (!isset($_SESSION['admin_username'])) {
  echo "<script>alert('Please login first');</script>";
  header("Location: ../admin_area/adminlogin.php");
  exit();
}

 
if(isset($_GET['edit_brands'])){
    $edit_brands=$_GET['edit_brands'];
    $get_brands="SELECT * FROM `brands` WHERE brand_id=$edit_brands";
    $result=mysqli_query($conn,$get_brands);
    $row=mysqli_fetch_assoc($result);
    $brand_title=$row['brand_title'];

    if(isset($_POST['Edit_brands'])){
        $brand_title=$_POST['brand_title'];
        $update_brands="UPDATE `brands` SET brand_title='$brand_title' WHERE brand_id=$edit_brands";
        $result_cate=mysqli_query($conn,$update_brands);
        if($result_cate){
            echo "<script> alert('Brands has been updated successfully')</script>";
            echo "<script>window.open('./view_brand.php','_self')</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h3 class="text-center text-success" id="viewcate">Edit brands</h3>
<form action="" method="post" class="mb-2">
<div class="input-group mb-3 w*90" >
  <span class="input-group-text" id="basic-addon1 bg-info" ><i class="fa-solid fa-receipt"></i></span>
  <input type="text" class="form-control" name="brand_title" placeholder="update brands" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo $brand_title; ?>">
</div>
<div class="input-group mb-0 w*10">
  <input type="submit" name="Edit_brands" class="bg-info p-4 border-0 my-3"> 
</div>
</form>

<style>
/* Form Styles */
form {
  max-width: 400px; /* Adjust form width */
  margin: 0 auto;
}

.input-group {
  margin-bottom: 15px; /* Adjust spacing between input groups */
}

.input-group-text {
  background-color: #17a2b8; /* Input group text background color */
  color: #fff; /* Input group text color */
}

.input-group input {
  border-radius: 0; /* Remove border-radius for input */
}

.input-group button {
  border-radius: 0; /* Remove border-radius for button */
  cursor: pointer;
}

/* Button Styles */
input[type="submit"],
button {
  background-color: #17a2b8; /* Button background color */
  color: #fff; /* Button text color */
  border: none;
  padding: 10px 20px; /* Adjust button padding */
}

input[type="submit"]:hover,
button:hover {
  background-color: #117a8b; /* Button background color on hover */
}

/* Responsive Styles */
@media (max-width: 576px) {
  form {
    max-width: 90%; /* Adjust form width for smaller screens */
  }
}
#viewcate{
  text-align: center;
}
</style>
    
</body>
</html>
