 
<?php session_start();
 if (!isset($_SESSION['admin_username'])) {

 
     echo "<script>alert('Please login first');</script>";
     header("Location: ../admin_area/adminlogin.php");
     exit();
 }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin Dasboard</title>
    <!-- boostrap css link -->
      <!-- boostrap css link--->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!---font awosome link---->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <!-- navbar  -->
   <div class="container-fluid p-0 mg-0">
    <!-- first child  -->
 <div class="navbar navbar-expand-lg navbar-light bg-info">
 <div class="container-fluid">
 <!-- <img src="" alt="" class="logo"> -->
  <nav class="navbar navbar-expand-lg">
  <div class="navbar-nav">
    <li class="nav-item">
<a href="" class="nav-link">Welcome <?php  echo $_SESSION['admin_username'] ?></a>

    </li>
  </div>
  </nav>
</div>
 </div>
 
<!-- third child -->
<div class="row">
<div class="col-md-12 bg-secondary p-1 ">

     
 
<p class="text-light text-center"><h1 class="text-center">Admin</h1> </p>
<!--     
<div class="">    <a href=""> <img src="../images/images (1).jpg" alt="" class="admin-image"></a>
</div> -->
<!-- create button and insert chance 4 -->
<div class="button1 text-center">
<button class="nav-link text-light bg-info my-1 "><a href="index.php?Insert-Product">Insert Product</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?view_product">View Product</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?insert-category">Insert Categories</a> </button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?view_category">view Categories</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?insert-brand">Insert Brand</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?view_brand">View Brands</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?list_orders">All Orders</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?viewallpayment">All Payment</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?list_user">List user</a></button>
<button class="nav-link text-light bg-info my-1 "><a href="index.php?adminlogout">Logout</a></button>
</div>
 


</div>

 
   </div>
<div class="container my-5">
<?php
 

if(isset($_GET['insert-category']))
{
include('insert-categories.php');

}
if(isset($_GET['insert-brand']))
{
include('Insert-Brand.php');

}
 if(isset($_GET['Insert-Product'])){
  include('Insert_product.php');
 }
 if(isset($_GET['view_product'])){
  include('view_product.php');
 }
 if(isset($_GET['edit_products'])){
  include('edit_products.php');
 }
 if(isset($_GET['delete_products'])){
  include('delete_products.php');
 }
 if(isset($_GET['view_category'])){
  include('view_category.php');
 }
  
 if(isset($_GET['edit_category'])){
  include('edit_category.php');
 }
 if(isset($_GET['delete_category'])){
  include('delete_category.php');
 }
 if(isset($_GET['view_brand'])){
  include('view_brand.php');
 }
  
 if(isset($_GET['edit_brands'])){
  include('edit_brands.php');
 }
 if(isset($_GET['delete_brands'])){
  include('delete_brands.php');
 }
 if(isset($_GET['list_orders'])){
  include('list_orders.php');
 }
 if(isset($_GET['delete_list_orders'])){
  include('delete_list_orders.php');
 }
 
 if(isset($_GET['viewallpayment'])){
  include('viewallpayment.php');
 }
 
 if(isset($_GET['deletepayment'])){
  include('deletepayment.php');
 }
 if(isset($_GET['deletelist_user'])){
  include('deletelist_user.php');
 }
 if(isset($_GET['list_user'])){
  include('list_user.php');
 }
 if(isset($_GET['adminlogout'])){
  include('adminlogout.php');
 }


 
  
  
 
 
 ?>
 
  
  
 
</div>

 
 
 <!-- this is a footer
 <div class="bg-info p-3 text-center"id="footer">
  <p> All right reversed design by muhammad ilyas @2024</p>
</div> -->
 
<!-- boostrap js link -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>



<style>
/* Global Styles */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

.container-fluid {
  padding: 0;
}

/* Navbar Styles */
.navbar {
  background-color: #17a2b8;
}

.navbar img.logo {
  height: 50px; /* Adjust logo height */
  margin-right: 10px;
}

.navbar .navbar-nav .nav-link {
  color: #fff;
  font-weight: bold;
}

.navbar .navbar-nav .nav-link:hover {
  color: #fff;
  background-color: rgba(255, 255, 255, 0.1);
}

/* Admin Image Styles */
.admin-image {
  width: 200px; /* Adjust admin image width */
  height: auto;
  border-radius: 50%;
}

/* Button Styles */
.button1 button {
  margin: 5px;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  font-weight: bold;
  cursor: pointer;
}

.button1 button a {
  color: #fff;
  text-decoration: none;
}

.button1 button:hover {
  opacity: 0.8;
}

/* Footer Styles */
#footer {
  background-color: #17a2b8;
  color: #fff;
  padding: 10px 0;
  text-align: center;
}

/* Responsive Styles */
@media (max-width: 768px) {
  .navbar img.logo {
    height: 40px;
  }

  .admin-image {
    width: 150px;
  }

  .button1 button {
    padding: 8px 16px;
  }
}

@media (max-width: 576px) {
  .navbar img.logo {
    height: 30px;
  }

  .admin-image {
    width: 120px;
  }
}
</style>
</body>
</html>
 

 
 